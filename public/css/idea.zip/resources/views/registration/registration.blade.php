@extends('homelayout.master')


@section('nav')     
@endsection



@section('css')
 
<style type="text/css">
 	
#file-upload {
  position: absolute;
  left: -9999px;
}

label[for="file-upload"] {
display: inline-block;
background: #9e98a2;
cursor: pointer;
color: white;
padding: 11px 7px;
transition: all .8s ease;
margin: 0px;
}
label[for="file-upload"]:hover {
  background: #257080;
}

#filename {
padding: 10px 7px;
float: left;
width: 78%;
white-space: nowrap;
overflow: hidden;
background: #e7e7e7;
font-size: 16px;
color: #8c8383;
}

 </style>
   

@endsection

@section('content')


<div class="col-sm-8" style="padding: 0px 50px;margin:auto">

	@if(Session::has('message'))
		<?php  $m = Session::get('message'); ?>
		<div class="alert alert2  alert-{!!$m['class']!!} fade in col-sm-12 animated fadeInRight" ><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a><strong>{!! $m['status']!!}  !</strong> {!! $m['text']!!}</div>
	@endif


	@if (count($errors) > 0)
		<div class="alert alert-danger">
			<ul>
				@foreach ($errors->all() as $error)
					<li>{{ $error }}</li>
				@endforeach
			</ul>
		</div>
	@endif 
	<script>setTimeout(function() {$(".alert").fadeOut(1000);},10000);</script>

 



	 <form action="{{url('Registration')}}" class="row" method="post" enctype="multipart/form-data">  

	  {!! csrf_field() !!} 



		 <input type="hidden" value="insert" name="action" >

		<h2 class="title"> Registration</h2>
		<span class="note">
		 Note: ** for required field.
	   </span>


		<div class="col-sm-6 field-box" style="clear: both"> 
			<div class="form-group">
			  <label class=" control-label"> Organization Name <span> **</span></label>  
			 <input  type="text"  name="orgName" value="{{old('orgName')}}" placeholder="Organization Name" class="form-control" required="">
			</div>
		</div>

		<div class="col-sm-6 field-box"> 
			<div class="form-group">
			  <label class=" control-label"> Organization ID <span> **</span></label>  
			 <input  type="text"  name="orgID" autocomplete="off" value="{{old('orgID')}}" placeholder="Organization ID" id="orgID" class="form-control" required="">
			<span class="text-danger exist" style="display: none;"> ID Already Exist  </span>
			</div>
		</div>


		<div class="col-sm-12 field-box"> 
			<div class="form-group">
			  <label class=" control-label"> Description   <span> **</span> </label>  
			 <textarea name="orgDesc"   placeholder="Organization Description" class="form-control"  required="">{{old('orgDesc')}}</textarea>   
			</div>
		</div>

		<div class="col-sm-12 field-box"> 
			<div class="form-group">
			  <label class=" control-label"> Address   <span> **</span> </label>  
			 <input  type="text"  name="Address" value="{{old('Address')}}" placeholder="Address" class="form-control"  required="">
			</div>
		</div>



		<div class="col-sm-6 field-box"> 
			<div class="form-group">
			  <label class=" control-label"> Phone/Mobile  <span> **</span></label>  
			 <input  type="text"  name="Phone" value="{{old('Phone')}}" placeholder="Phone/Mobile" class="form-control" required="">
			</div>
		</div>



		<div class="col-sm-6 field-box"> 
			<div class="form-group">
			  <label class=" control-label"> Email   </label>  
			 <input  type="text"  name="Email" value="{{old('Email')}}" placeholder="Email" class="form-control"  >
			</div>
		</div>
	   <div class="col-sm-6 field-box"> 
			<div class="form-group">
				  <label class="control-label" style="width: 100%;"> Logo    </label>  
			   <span id="filename"> Select your file</span>
  			   <label for="file-upload" class="upload-label">Browse<input type="file" id="file-upload" name="orgLogo"></label>
  			    <i style="float:left">Image Must be PNG,JPG and 200x200</i>
			 </div>
		</div>
 

		<div class="col-sm-11 submit-box">
			<button class="btn " type="Submit" id="submit"> Submit Information</button>
		</div>
		
	   
	</form>

@endsection


@section('footer')
 
<script type="text/javascript">
	
	 $('#file-upload').change(function() {
    var filepath = this.value;
    var m = filepath.match(/([^\/\\]+)$/);
    var filename = m[1];
    $('#filename').html(filename);

});


	  $("#orgID").on('keyup keypress change',function(e){
 
	   

	  var orgID=$(this).val(); 

	  	$.ajax({
		    type:  "post",
		    data:  {orgID: orgID,action:'CheckOrgID'},
		    cache: false,
		    url:   "{{url('Registration')}}", 
		    success: function (result) {   

		    	if(result==1){

		    	$(".exist").show();
		    	$("#submit").hide();

		    	}else{

		    	$(".exist").hide();
		    	$("#submit").show();

		    	}
				
 		    },
		    error: function(){
		   
			}
		});
  });

</script>
 
@endsection