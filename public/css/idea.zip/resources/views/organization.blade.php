<!doctype html>
<html lang="{{ app()->getLocale() }}">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Contact Management System</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">

        <!-- Styles -->
        <style>


        *{
            box-sizing: border-box;
        }
            html, body {
                background-color: #fff;
                color: #636b6f;
                font-family: 'Raleway', sans-serif;
                font-weight: 100;
                height: 100vh;
                margin: 0;
            }

            .full-height {
                height: 100vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
                max-width: 600px;
                width:100%;
                margin: auto;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                text-align: center;
            }

          

            .links > a {
                color: #636b6f;
                padding: 0 25px;
                font-size: 12px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }
.org-box{
        width:50%;
          padding:10px;
          float:left;
}

.org-box>.box{
padding: 10px;
box-shadow: 1px 2px 5px 5px rgba(0,0,0,0.1);
min-height: 100px;
    min-width: 200px;
}


.org-box>.box>.title{
font-size: 20px;
display: block;
font-weight: bold;
text-decoration: none;
padding: 6px 10px;
color: #7a8686;
}
.org-box>.box>.address{
font-size: 15px;
}
.org-box>.box>.desc{
margin: 0px;
padding-top: 5px;

}

.org-box>.box>.thumb>img{
    height: 80px
}


        </style>
    </head>
    <body>


        <div class="flex-center position-ref full-height">
            @if (Route::has('login'))
                <div class="top-right links">

                        <a href="{{ url('/') }}">Home</a>
                    @auth 
                        <a href="{{ url( Auth::user()->type->typeRoute ) }}">{{Auth::user()->type->typeRoute}}</a>
                    @else
                        <a href="{{ route('login') }}">Login</a>
                        <a href="{{ url('Registration') }}">Registration</a>
                    @endauth
                </div>
            @endif



            <div class="content"> 
                <?php

$organization=DB::table('organizations')->get();


                ?>
@foreach($organization as $org)

               <div class="org-box">
                   <div class="box">
                       <div class="thumb">
                        <img src="{{asset('public/asset/upload/org/'.$org->picture)}}">
                           
                       </div>
                       <a href="#" class="title" > {{ $org->orgName}}</a>
                       <span class="address">{{$org->address}}</span>
                       

                   </div>
               </div>
@endforeach
            </div>
        </div>
    </body>
</html>
