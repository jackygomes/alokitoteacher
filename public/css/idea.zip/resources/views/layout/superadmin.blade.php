  <!DOCTYPE html>
<head>
  <meta charset="utf-8">
 <title> Dashboard  </title> 
 
<meta name="viewport" content="width=device-width">   

 
 <link rel="icon"   href="{{ asset('public/assets/img/logo.png') }}" />
  
 <script src="{{ asset('public/assets/js/jquery.min.js') }}"></script> 
    
<script type="text/javascript">
  $.ajaxSetup({
      headers: {
          'X-CSRF-TOKEN': "{{csrf_token()}}"
      }
  });
</script>
 

 <link rel="stylesheet" href="{{asset('public/assets/font-awesome-4.7.0/css/font-awesome.min.css')}}" />
 <link rel="stylesheet" href="{{asset('public/assets/bs4/css/bootstrap.min.css')}}">

 <link rel="stylesheet" href="{{ asset('public/assets/css/animation.css') }}"> 
 <link rel="stylesheet" href="{{ asset('public/assets/css/style.css') }}" > 
 <link rel="stylesheet" href="{{ asset('public/assets/css/responsive.css') }}"> 
 <style type="text/css">
   .form-group>label>span{
  color:red
}
 </style>
 
 @yield('header')
  
</head>

<body>

  <div id="body-Wraper">


       <nav class="navbar navbar-expand-sm  ">
        <!-- Brand -->
        <a class="navbar-brand" style="min-width: 200px; text-align: right;" href="#">  <span class="name"> OgrooCom | Bulk SMS </span class="arrow"> <span class="arrow"><i class="fa fa-angle-double-right" ></i> </span></a>
 

        <!-- Right Nav -->
        <ul class="navbar-nav  " style="margin-left: auto;"> 

          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle " href="#"   data-toggle="dropdown"> 
              <i class="fa fa-commenting-o" ></i> <span class="badge badge-primary">4</span> 
            </a>
            <div class="dropdown-menu">
              <div class="nHeader"> You have 0 messages</div>
              
              <!-- <a class="dropdown-item" href="#">Link 1</a>   -->

              <div class="nFooter"><a class="nav-link" href="#">See All Messages</a></div>

            </div>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle " href="#"   data-toggle="dropdown"> 
              <i class="fa fa-bell"></i> <span class="badge badge-primary">4</span>
            </a>
            <div class="dropdown-menu">
              <div class="nHeader">You have 0 messages</div>

              <!-- <a class="dropdown-item" href="#">Link 1</a>   -->

              <div class="nFooter"><a class="nav-link" href="#">See All Messages</a></div>

            </div>
          </li>
 
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle userAvater" href="#" id="navbardrop" data-toggle="dropdown">
              <img src="{{asset('public/assets/img/defauluser.png')}}" />
              <span>Super Admin</span>
            </a>
            <div class="dropdown-menu">
              <div class="header" >

              <img src="{{asset('public/assets/img/defauluser.png')}}"> 
              <p> Super Admin</p>

              </div> 
              <div class="footer" >

             <div><a href=""  class="nav-link"> Profile </a></div>
             <div><a href=""  class="nav-link"   onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();"> Logout </a></div>

              </div> 

            </div>
          </li>
        </ul>
      </nav>

  <form id="logout-form"  action="{{ route('logout') }}" method="POST" style="display: none;">
                                        @csrf
                                    </form>




 <div class="main-container">

   <div class="sidenav">
     <ul class="menu sideNavArea">

   @yield('sidenav')

   </ul>
 
   </div>

   <div class="mobileNavFooter"></div>

 <div class="main-content">

@yield('content')
 

 
   </div> 


 </div> <!-- end main container -->




<footer>
  
<span>  ©  Copyright 2019</span>

<span class="right">
   Developed By    <a href=""> AL EMRAN</a>
</span>

</footer>



 </div>  <!-- end body wrapper -->

<script src="{{ asset('public/assets/bs4/js/bootstrap.min.js')}}"></script>   
<script src="{{ asset('public/assets/js/index.js')}}"></script>   
 
@yield('footer')
 

</body>
</html>
  
 