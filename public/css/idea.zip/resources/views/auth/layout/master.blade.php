<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title> OgrooCom | Authentication</title>

    <!-- Styles -->
    <link rel="stylesheet" href="{{asset('public/assets/bs4/css/bootstrap.min.css')}}">
    <link href="{{asset('public/assets/authAsset/style.css')}}" rel="stylesheet">

   <link rel="icon"   href="{{asset('public/assets/img/logo.png')}}" />
  

    <!-- Scripts -->

<script type="text/javascript" src="{{asset('public/assets/js/jquery.min.js')}}"></script> 
    <script>
        window.Laravel = <?php echo json_encode([
            'csrfToken' => csrf_token(),
        ]); ?>
    </script>
 

</head>
<body>
 

 
        @yield('content')


        

  <div class="footer">
   © 2019 <?php date('Y') ?>  | Developed by <a href="http://ogroosoft.com" > OgrooSoft </a>
 
</div>
 

    <!-- Scripts -->
   
<script type="text/javascript" src="{{asset('public/assets/authAsset/particle.js')}}"></script>
</body>
</html>
