@extends('auth.layout.master')


@section('title') Registration @endsection


@section('content')

<style type="text/css">


.form-group>label>span{
  color:red;
}

</style>

<div id="registerbox" class="justify-content-center"  > 

  <div class="authentication-area align-self-stretch">

    <div class="logo"><img src="public/assets/img/logo.png" height="50px" /></div>

    <h3 class="title">Registration</h3>
    <hr class="colorgraph">
    
    @if(Session::has('message'))
    <?php  $m = Session::get('message'); ?>
    <div class="alert alert2  alert-{!!$m['class']!!} col-sm-12 animated fadeInRight" ><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a><strong>{!! $m['status']!!}  !</strong> {!! $m['text']!!}</div>
    @endif


    @if ($errors->any())
    <div class="alert alert-danger">
      <ul>
        @foreach ($errors->all() as $error)
        <li>{{ $error }}</li>
        @endforeach
      </ul>
    </div>
    @endif

    <form name="form" id="form" class="login"  method="POST" action="{{ url('/Registration') }}" enctype="multipart/form-data" >
      <p>If you face any problem, please call to 01766603578</p>
      {{ csrf_field() }}

<input type="hidden" name="action" value="insert">
      <div class="form-group">
        <label> Organization Name <span>***</span></label>
        <input  type="text"  name="orgName" value="{{old('orgName')}}"   class="form-control" required="">
      </div>

      <div class="form-group">
       <label> Organization Mobile <span>***</span></label>
       <input  type="text"  name="phone" value="{{old('phone')}}" placeholder="" class="form-control" required="">
     </div>

     <div class="form-group">
       <label> Organization Email </label>
       <input  type="text"  name="Email" value="{{old('Email')}}" placeholder="" class="form-control"  >
     </div>




     <div class="form-group">
       <label> Organization Address <span>***</span></label>
       <input  type="text"  name="Address" value="{{old('Address')}}" placeholder="" class="form-control"  required="">
     </div> 


     <div class="form-group">
       <label> Organization Description  </label>
       <textarea name="orgDesc" maxlength="300"  placeholder="" class="form-control"  >{{old('orgDesc')}}</textarea>
     </div>


     <div class="input-group mb-3">  

       <div class="custom-control custom-switch">
        <input name="agreed" value="agreed" required="" type="checkbox" class="custom-control-input" id="switch1">
        <label class="custom-control-label" for="switch1">I Agree  </label>
      </div>

    </div> 



    <div class="auth-footer"> 
      <a href="{{url('login')}}">Login</a>

      <button type="submit" href="#" class="btn btn-primary float-right" ><i class="glyphicon glyphicon-log-in"></i> Sign Up</button>                          
    </div>


  </form>   


</div>


</div> 

<div id="particles"></div>


@endsection
