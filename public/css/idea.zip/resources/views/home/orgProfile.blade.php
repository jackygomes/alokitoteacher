
 @extends('home.fixed.master') 



 @section('title')

{{$organization->orgName}}

 @endsection



 @section('titlebar')

{{$organization->orgName}}

 @endsection


 @section('header')
 
     <link rel="stylesheet" href="{{asset('asset/contacts/css/about.css')}}">
      <link rel="stylesheet" href="{{asset('asset/css/contactsList.css')}}">
      <link rel="stylesheet" href="{{asset('asset/css/ogrooModal.css')}}">

 
 @endsection



 @section('content')

<div class="main-content" id="main-content">


<div class="slider">
  
  <div class="item">
    <img src="{{asset('asset/upload/org/'.$organization->pictures)}}"  >
    <h4> Welcome to<br>   Contacts Book Application </h4> 
    <p> Search your desired person with  designation, name , Mobile ,Email and call, email, message singly or group</p>
  </div>

</div>
 



<div class="contactCat" id="contacts">
  <h3> <img src="{{asset('asset/contacts/img/contact.png')}}"> <p >Contact Department</p></h3>

 
<div class="menuContainer" id="app">
 
 <ul class="menu" id="contactMenu">

 <?php 


  foreach( $categories as  $c){

  $subclass=(count($c->subCat)>0?['sub','<i>&#x25BC;</i>','<ul class="dropdown">','</ul>']:[NULL,NULL,NULL,NULL]);
 
          echo '<li><a href="" data-id="'.$c->concernid.'" class="'.$subclass[0].'">'.$c->catName.$subclass[1].'</a>' ;

           echo  $subclass[2];
                         foreach( $c->subCat as  $sc1){

                           $subclass1=(count($sc1->subCat)>0?['sub','<i>&#x25BC;</i>','<ul class="dropdown">','</ul>']:[NULL,NULL,NULL,NULL]);
               
                          echo '<li><a href="" data-id="'.$sc1->concernid.'" class="'.$subclass1[0].'">'.$sc1->catName.$subclass1[1].'</a>' ;
                                 echo  $subclass1[2];
                                foreach( $sc1->subCat as  $sc2){
                                  $subclass2=(count($sc2->subCat)>0?['sub','<i>&#x25BC;</i>','<ul class="dropdown">','</ul>']:[NULL,NULL,NULL,NULL]);             
                               echo '<li><a href="" data-id="'.$sc2->concernid.'" class="'.$subclass2[0].'">'.$sc2->catName.$subclass2[1].'</a>' ;
                                echo  $subclass2[2];

                                      foreach( $sc2->subCat as  $sc3){

                                        echo '<li><a href="" data-id="'.$sc3->concernid.'" class="">'.$sc3->catName.'</a></li>' ;

                                      }

                                echo  $subclass2[3];
                                echo '</li>';
                                }  
                          echo  $subclass1[3];
                       echo   '</li>';
                         }
            echo  $subclass[3];
          echo  '</li>';
  };
         
 
      ?>

  </ul>   
 
 <!-- <li ><a href="" class="sub"> BCS Cadre Officer<i>&#x25BC;</i></a>
            <ul class="dropdown">
               <li><a href=""  class="sub"> Direct Recruitment <i>&#x25BC;</i></a>
                     <ul class="dropdown">
                      <li><a href=""> 3rd Batch </a></li>
                      <li><a href=""> 4rd Batch </a></li>
                      <li><a href=""> 5rd Batch </a></li>
                      </ul>
                </li> -->

</div>  
 


<div class="ogroo-modal" id="contactModal" data-outsideClick="false">
    <div class="ogroo-modal-body">
      <div class="ogroo-modal-head">
         <span id="title"></span>     <span class="ogroo-modal-close hideModal">&#10006;</span>
      </div>
      <div class="ogroo-modal-content">
  

<div class="search-container">
  <div class="search">
    <input type="text" placeholder="Search Person" id="searchPerson">
    <div class="selector">

      <div class="button-box"> 
        <label><input type="checkbox" class="ContactSelector"   id="message" /><span>Message</span> </label>
        <label><input type="checkbox" class="ContactSelector"  id="email" /><span>Email</span> </label>
      </div>
      
    </div>
  </div>

</div>




<div class="main-content" id="main-content">  

 
<div class="contactCat" style="margin-top: 10px;clear:both">
 
 
<div class="ContactsMenuContainer">
   <label class=" check" id="allSelect"> <input type="checkbox" value="01684421349"  name="check"/><span>All Select </span></label>
    <ul class="ContactsList" id="ContactsList"> 
   
         
  </ul>
<!-- 
   <li><a href="">Zohurul Islam<b>, Vice-President</b> <span><i> 01684421349</i>,monir_894@yahoo.com </span> </a>
           <label class="message check"><input type="checkbox" value="01684421349" name="check"/><span> </span></label>
           <label class="email check"><input type="checkbox"  value="monir_894@yahoo.com" name="email"/><span> </span></label>
        
          
         </li>
       -->
  <div class="popup-box">
    <a href="#">Copy Mail Address</a>
  </div>

<script type="text/javascript">




</script>



</div>

</div>

</div>
      </div>
      <div class="ogroo-modal-footer">
         <button class="ogroo-button hideModal"> Close</button>
      </div>
    </div>


</div>


<script type="text/javascript">
  

$(document).ready(function(){
  $("#searchPerson").on("keyup", function() {
    var value = $(this).val().toLowerCase();

    $("#ContactsList").find('li').filter(function() {
             $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });


  });
});





  $("#contactMenu li>a").click(function(e){
    e.preventDefault();
    var catID=$(this).attr('data-id');

    if($(this).hasClass('sub')){
      return false;
    }


  var loading= webToast.loading({
                 status:'Loading...',
                 message:'Please Wait a moment...'
                 });


       
        $.ajax({
        type:  "post",
        data:  {catID: catID,'action':'updateData'},
        cache: false,
        url:   "{{url('ContactsDetails')}}", 
        success: function (resultdata) {
              loading.fadeOut(500,function(){
                loading.remove();
              });

              $("#searchPerson").val('');
              $(".ContactsList").html(resultdata.data);
              $("#title").html(resultdata.title);
            /* 
          webToast.Success({
                       status:'Success !',
                       message:'Collection Submited Successfully',
                       delay:10000
                     });*/
            $( "#contactModal" ).ogrooModal('show');
        },
        error: function(){
       
          }
      });

  })

$(".ContactsList").on('click','li>a',function(e){
  e.preventDefault();


  var person=JSON.parse($(this).attr('data-person'));

         $("#pOffice").text(person.concernName) ; 

         $("#pName").text(person.personName) ; 
         $("#pDesig").text(person.designationName) ; 
         $("#pDesig").text(person.designationName) ; 
         $("#pEmail").text(person.email) ; 
         $("#pMobile").text(person.mobileNo) ; 
         $("#pAddress").text(person.address) ; 
          
    $("#personalDetails").ogrooModal('show');

})
</script>



</div>

 

<div class="ogroo-modal" id="personalDetails"  >
    <div class="ogroo-modal-body" style="max-width: 400px"> 
               <span class="ogroo-modal-close hideModal">&#10006;</span>
    
      <div class="ogroo-modal-content" >
        <div class="personData">
          <img src="{{asset('asset/img/defauluser.png')}}">
          <h3 id="pName"> </h3>
          <p class="d" id="pDesig"> </p>

<ul>
  <li><img src="{{asset('asset/img/email.png')}}"> <span id="pEmail"></span></li>
  <li><img src="{{asset('asset/img/phone.png')}}"> <span id="pMobile"> </span></li>
  <li><img src="{{asset('asset/img/address.png')}}"> <span id="pAddress">   </span></li>
</ul>

<p><b> Office : </b>  <span id="pOffice"></span> </p>
        <!-- <p>
       <b> Others Contacts: </b> 0215487545,01515287271 </p> -->
       <!--  <p class="about" style="display: none;"><b> About/Remarks: </b>  Our Story. Website.com began in 2005. After years in the web hosting industry, we realized that it was near impossible for the average Jane or Joe to create thei</p>
        </div> -->
        
  
      </div> 
    </div>


</div> 
</div>



<div class="welcome-message">
 

 <?php




 ?>

  <div class="message">
    
    <div class="mbox">
      <img src="{{asset('asset/contacts/img/sarwar.png')}}"/>
      <p style="color: #FF1493;"><b>Mohammad Golam Sarwar Bhuiyan</b></p>
      <p><b>BCS Audit & Accounts Association</b> was born with the aim and objective of serving the People and the Country, and with a vision of building Bangladesh as an economically developed and self-reliant country. </p>
    </div>

  </div> 



  <div class="message">
    
    <div class="mbox">
      <img src="{{asset('asset/contacts/img/kazisafiqulazam.jpg')}}"/>

      <p  style="color: #FF1493;"><b>Kazi Safiqul Azam</b></p>
      <p>Pre</p>
      <p><b>BCS Audit & Accounts Association</b> was born with the aim and objective of serving the People and the Country, and with a vision of building Bangladesh as an economically developed and self-reliant country. </p>
    </div>

  </div> 

</div>

<div class="about-container" id="about">
 		{!! $organization->orgDesc !!}
</div>









</div>


@endsection


@section('footer')

 
    <script src="{{asset('asset/js/contactsList.js')}}"></script>
    <script src="{{asset('asset/js/ogrooModal.js')}}"></script>
    <script src="{{asset('asset/js/WebToast.min.js')}}"></script>



@endsection