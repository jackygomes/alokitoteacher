<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>  @yield('title') </title>
  
  <!-- 
  <link rel='stylesheet prefetch' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css'> -->

   <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  
  <meta name="csrf-token" content="{{ csrf_token() }}"> 

      <link rel="stylesheet" href="{{asset('asset/contacts/css/style.css')}}">
      <link rel="stylesheet" href="{{asset('asset/contacts/css/responssive.css')}}">
    <script src="{{asset('asset/contacts/js/jquery.min.js')}}"></script>
<script type="text/javascript">
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': "{{ csrf_token() }}"
                }
            });

  </script>

    @yield('header')
  
</head>

<body  >

  <div class="main-container">
  <div class="container" style="margin-bottom: 200px">

<div class="nav-button">
  <button class="btn btn-nav-left"> &#9776; </button>
<h2 class="title"> @yield('titlebar') </h2>
  
  <button class="btn-nav-right"> &#8942; </button>
  
</div>
    
   <div class="side-nav left" id="leftNav">
    <ul class="nav">
       <li><a href=""> Home </a></li>
       <li><a href="#about"> About </a></li>
       <li><a href="#contacts"> Address Book </a></li> 
       <li><a href="#contacts"> Contact US </a></li> 
    </ul>
    
  </div>
    
    <div class="side-nav right" id="right">
    <ul class="nav">
      <li><a href=""> Home </a></li> 
    </ul>
    
  </div>


  
  <div class="nav-bg l" ></div>  
  <div class="nav-bg r" ></div>  
    
    <script type="text/javascript">
      $(".btn-nav-left").on('click',function(){

          $("#leftNav").toggleClass('activeLeftNav');
          $(".nav-bg.l").fadeToggle();
      });


            $(".btn-nav-right").on('click',function(){

          $("#right").toggleClass('activeRightNav');
          $(".nav-bg.r").fadeToggle();


      });

         $(".nav-bg.l").click(function(){
           $("#leftNav").removeClass('activeLeftNav'); 
           $(this).fadeOut();

         }) ;


         $(".nav-bg.r").click(function(){ 
           $("#right").removeClass('activeRightNav');
           $(this).fadeOut();

         })   
    </script>
    
    








@yield('content')











  
</div>
  
 </div> 



  <script type="text/javascript">
 

 $(".menu a.sub").click(function(e){
  e.preventDefault();
  $(this).next('.dropdown').slideToggle()
})

  </script>


@yield('footer')


</body>

</html>
