@include('homelayout.header')

@yield('nav')


@yield('content')


@include('homelayout.footer') 