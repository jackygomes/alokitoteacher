  
</div>
</div>

<footer  style="background: transparent;">

 
  
  
  <span class="right"> Developed by <a href="#"   style="color:yellow">OgrooSoft</a></span>

</footer>

  <noscript id="deferred-styles">

 <link rel="stylesheet" href="{{asset('public/assets/font-awesome-4.7.0/css/font-awesome.min.css')}}" />
  <link rel="stylesheet" href="{{asset('public/assets/bs4/css/bootstrap.min.css')}}">
  <link rel="stylesheet" href="{{asset('public/assets/css/style.css')}}">
  <link rel="stylesheet" href="{{asset('public/assets/css/design.css')}}">
  @yield('css')
  <style type="text/css">
*{
  font-family: 'Nunito', sans-serif;
  }
.active{
  color: #18bc95 ! important;
}
</style>
 </noscript>


    <script>
      var loadDeferredStyles = function() {
        var addStylesNode = document.getElementById("deferred-styles");
        var replacement = document.createElement("div");
        replacement.innerHTML = addStylesNode.textContent;
        document.body.appendChild(replacement)
        addStylesNode.parentElement.removeChild(addStylesNode);
      };
      var raf = requestAnimationFrame || mozRequestAnimationFrame ||
          webkitRequestAnimationFrame || msRequestAnimationFrame;
      if (raf) raf(function() { window.setTimeout(loadDeferredStyles, 1); });
      else window.addEventListener('load', loadDeferredStyles);
    </script>
 


	
 @yield('footer')
<script src="{{asset('public/assets/bs4/js/bootstrap.min.js')}}"></script>  
<script src="{{asset('public/assets/js/index.js')}}"></script>   
<script src="{{asset('public/assets/js/ripple.js')}}"></script>   

</body>
</html>
  
