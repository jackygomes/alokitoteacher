  

  <!--////////////////////////////
     ///////side nav start///////
    ////////////////////////////  -->  

 
<div class="sidenav">
	 <ul class="menu">
        <li  >
        <a href="{{url('/')}}" class="ripple" data-ripple-color="#89669b">
            <i class="fa fa-home"/></i> 
            <span> Dashboard </span>        
        </a>

         </li> 
		<li >
           <a class="ripple" data-ripple-color="#89669b" href="#"><i class="fa fa-address-book-o" aria-hidden="true"></i> <span>Customer Management <i class="fa fa-angle-down right"></i></span> </a>
            <ul class="dropdown-nav">
                 
              <li><a href="{{url('CreateCustomer')}}"> Customer Create </a></li>
              <li><a href="{{url('CustomerList')}}"> Customer List</a></li>
              <li><a href="#"> Customer Details</a></li>
              <li><a href="#">  Customer Filtering</a></li>
            </ul>
		</li>


<li >
           <a class="ripple" data-ripple-color="#89669b" href="#"><i class="fa fa-address-book-o" aria-hidden="true"></i> <span>package Management <i class="fa fa-angle-down right"></i></span> </a>
            <ul class="dropdown-nav">
                 
             <li><a class="ripple" data-ripple-color="#89669b" href="{{url('PackageCreate')}}">  <span> Package Create</span></a></li>

              <li><a href="{{url('PackageList')}}"> Package List</a></li>
     
            </ul>
    </li>



      
        <li><a class="ripple" data-ripple-color="#89669b" href="#"><i class="fa fa-home"/></i> <span>Student Attendance</span></a></li>
         
		<li>
           <a class="ripple" data-ripple-color="#89669b" href="#"><i class="fa fa-home"/></i> <span>Home <i class="fa fa-angle-down right"></i></span> </a>
            <ul class="dropdown-nav">
                 
              <li><a href="#"><i class="fa fa-home"/></i>  Student Attendance </a></li>
              <li><a href="#"><i class="fa fa-home"/></i>  Student Attendance 5</a></li>
              <li><a href="#"><i class="fa fa-home"/></i>  Student Attendance 2</a></li>
              <li><a href="#"><i class="fa fa-home"/></i>  Student Attendance 3</a></li>
            </ul>
		</li>

       <li><a href="#"><i class="fa fa-home"/></i> <span>Home</span></a></li>
       <li><a href="#"><i class="fa fa-home"/></i> <span>Home</span></a></li>
	   
	   <li>
           <a class="ripple" data-ripple-color="#89669b" href="#"><i class="fa fa-home"/></i> <span>Home <i class="fa fa-angle-down right"></i></span> </a>
            <ul class="dropdown-nav">
                 
              <li><a href="#"><i class="fa fa-home"/></i>  Student Attendance </a></li>
              <li><a href="#"><i class="fa fa-home"/></i>  Student Attendance 5</a></li>
              <li><a href="#"><i class="fa fa-home"/></i>  Student Attendance 2</a></li>
              <li><a href="#"><i class="fa fa-home"/></i>  Student Attendance 3</a></li>
            </ul>
		</li>
		
		<li>
           <a class="ripple" data-ripple-color="#89669b" href="#"><i class="fa fa-home"/></i> <span>Home <i class="fa fa-angle-down right"></i></span> </a>
            <ul class="dropdown-nav">
                 
              <li><a href="#"><i class="fa fa-home"/></i>  Student Attendance </a></li>
              <li><a href="#"><i class="fa fa-home"/></i>  Student Attendance 5</a></li>
              <li><a href="#"><i class="fa fa-home"/></i>  Student Attendance 2</a></li>
              <li><a href="#"><i class="fa fa-home"/></i>  Student Attendance 3</a></li>
            </ul>
		</li>
         	
      </ul>
       
	
	</div>


   

  <!--////////////////////////////
     /////main content start/////
    ////////////////////////////  -->  
 <div class="main-content">

 
 