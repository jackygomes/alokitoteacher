  <!DOCTYPE html>
<head>
  <meta charset="utf-8">
 <title>Contact Management | @yield('title') </title>
 
 
  <meta name="viewport" content="width=device-width">   

  <meta name="csrf-token" content="{{ csrf_token() }}"> 
 

   <link rel="icon"   href="{{asset('public/assets/img/logo.PNG')}}" />
  
<script src="{{asset('public/assets/js/jquery.min.js')}}"></script> 

<script type="text/javascript">

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': "{{ csrf_token() }}"
                }
            });
 

 </script>



 <style> 

.loading-main{position:fixed;width:100%;bottom:0;top:0;left:0;right:0;z-index:9999;background:#bec3c7;display:flex;justify-content:center;align-items:center}@keyframes mask{0%{transform:rotate(0deg)}100%{transform:rotate(360deg)}}
.spin{display:inline-block;position:relative;
  font-size:100px;
  width:1em;
  height:1em;
  border-radius:50%;
  background:#123456;
  box-shadow:inset 0 0 0 .12em rgba(0,0,0,0.2),0 0 0 .12em rgba(255,255,255,0.1);
  background:-webkit-linear-gradient(#D8C018 50%,#2ACED6 50%),linear-gradient(#D61419 50%,#1C5A07 50%);
  background:-webkit-linear-gradient(#D8C018 50%,#2ACED6 50%),-webkit-linear-gradient(#D61419 50%,#1C5A07 50%);
 background: linear-gradient(#D8C018 50%,#2ACED6 50%),linear-gradient(#da999b 50%,#7cd65e 50%);
  background-size:50% 100%,50% 100%;background-position:0 0,100% 0;background-repeat:no-repeat;opacity:.7;animation:mask 1s infinite linear}.spin:after{content:"";position:absolute;border:.12em solid rgba(255,255,255,0.3);position:absolute;top:25%;left:25%;width:50%;height:50%;border-radius:inherit}

 
 
 
</style>

@yield('header')

</head>
<body>
 
<!--  ////////////////////////////
     ///////LOADING EFFECT///////
    ////////////////////////////-->

 

<section class='loading-main'> 
 <div class='spin'></div>
  
</section>

<!--JavaScript-->

 <script>
$(window).bind("load", function() {
  
  
 
setTimeout(function(){ 

$(".loading-main").fadeOut(500);

 }, 500);

}); 
 </script>


<!--  ////////////////////////////
     /////END LOADING EFFECT/////
    ////////////////////////////-->





<!--  ////////////////////////////
     /////////TOP MENU///////////
    ////////////////////////////-->

<div class="navbar navbar-inverse justify-content-center" role="navigation" style="background: transparent;">
      
    
    <a href="{{url('/')}}"  style="font-size:20px;    color: #004085;padding: 10px;margin: 0px;">  Contact Management System     </a> 
 
       
  

    
    </div>

<!--  ////////////////////////////
     ////////TOP MENU END////////
    ////////////////////////////-->
 
  <!--////////////////////////////
     ///////body area start//////
    ////////////////////////////  -->


  <div class="main-container">

<link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">