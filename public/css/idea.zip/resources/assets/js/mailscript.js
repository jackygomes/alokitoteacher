
	Vue.component('CategoryMenu',{
  			 template : '<ul class="menu">'+
	 '<li v-for="cat in orgCategory" >{{ cat.catName  }}-{{ cat.concernid  }}   </li>'+
	 '</ul> '
		});



  new Vue({
        el: '#app',

        data: {
            orgCategory: []  
        },

        created: function () {

        	 this.fetchData();  

        },
		  mounted: function(){
		  			 		 
		  }, 
        methods: {

            fetchData: function () {
             let vm=this;
               axios.get('http://localhost/contactmanage/public/api/ContactsCategory/2')
      				.then(function (response) {
       					  vm.orgCategory=response.data.category ;
 
       			 
     				 })	
      	      },

            saveData: function (key,data) {

                	localStorage.setItem(key, JSON.stringify(data));
 
					   	
            },

            saveOrgData: function (obj) {
      
      	 		 obj.forEach(function(value) { 

					console.log(value.catName);

 				});
 
                	 
            } 
        }

    }) ;
	