<?php
namespace App\Http\Middleware;

use Closure;
use Illuminate\Contracts\Auth\Guard;

class Admin
{
    protected $auth;
    
    public function __construct(Guard $auth)
    {
        $this->auth = $auth;
    }
    
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {  
      
      if ($this->auth->guest()) {

                return redirect()->guest('login');

        } 
 
      if($this->auth->user()->type->typeRoute=='Admin'){ 
                return $next($request);
        }
               

     return redirect($this->auth->user()->type->typeRoute);      
 
           
          

    }
}
