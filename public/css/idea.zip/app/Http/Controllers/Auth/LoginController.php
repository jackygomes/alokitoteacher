<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Auth;
use DB;
use Request;

class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = '/';



  
protected function authenticated( $user)
    {
        

        DB::table('user_login_log')->insert([
            'userID'=>Auth::user()->id,
            'logindatetime'=>date('Y-m-d h:i:s'),
            'loginuserIP'=>Request::getClientIp(),
            'loginuserAgent'=> isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : 'none',
            'loginSessionID'=> session()->getId(),
        ]);
 
  return redirect(Auth::user()->type->typeRoute);
 

 }
 




    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest')->except('logout');
    }
}
