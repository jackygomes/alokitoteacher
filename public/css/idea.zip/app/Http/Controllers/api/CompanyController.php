<?php

namespace App\Http\Controllers\api;

use App\models\Company;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class CompanyController extends Controller
{


    public function create(Request $request){

        $validator = Validator::make($request->all(), [
            'PortalUserId' => 'required',
            'CompanyName' => 'required',
            'PhoneNumber' => 'required',
        ]);

        if ($validator->fails()) {
            return response()->json(['error' => $validator->errors()], 401);
        }

       // DB::table('resourcetracker_company')->insert([
      $company = Company::create([
            'PortalUserId'=>$request->PortalUserId,
            'CompanyName'=>$request->CompanyName,
            'Address'=>$request->Address,
            'PhoneNumber'=>$request->PhoneNumber,
            'ImageFileName'=>$request->ImageFileName,
            'ImageFileId'=>$request->ImageFileId,
            'CreatedDate'=>date('Y-m-d h:i:s'),
            'MaximumOfficeHours'=>$request->MaximumOfficeHours,
            'OfficeOutTime'=>$request->OfficeOutTime,
        ]);

        return response()->json([
            'status'=> 'success',
            'data'=> $company
        ], 200);

    }




    public function update(Request $request){

        $validator = Validator::make($request->all(), [
            'id' => 'required',
        ]);

        if ($validator->fails()) {
            return response()->json(['error' => $validator->errors()], 401);
        }

       // DB::table('resourcetracker_company')->insert([
      $company = Company::where('id', $request->id)->first();
        if($company){
            $company->update([
                'PortalUserId'=> $request->PortalUserId ? $request->PortalUserId  : $company->PortalUserId,
                'CompanyName'=> $request->CompanyName ? $request->CompanyName  : $company->CompanyName,
                'Address'=>$request->Address ? $request->Address  : $company->Address,
                'PhoneNumber'=>$request->PhoneNumber ? $request->PhoneNumber  : $company->PhoneNumber,
                'ImageFileName'=>$request->ImageFileName ? $request->ImageFileName  : $company->ImageFileName,
                'ImageFileId'=>$request->ImageFileId ? $request->ImageFileId  : $company->ImageFileId,
                'MaximumOfficeHours'=>$request->MaximumOfficeHours ? $request->MaximumOfficeHours  : $company->MaximumOfficeHours,
                'OfficeOutTime'=>$request->OfficeOutTime ? $request->OfficeOutTime  : $company->OfficeOutTime,
            ]);
        }


        return response()->json([
            'status'=> 'success',
            'data'=> $company
        ], 200);

    }






    public function details(Request $request){

        $companyDetails = Company::where('PortalUserId', $request->userId)->get();
        return response()->json( $companyDetails , 200);
    }





    public function deleteCompany(Request $request){
        $validator = Validator::make($request->all(), [
            'id' => 'required',
        ]);

        if ($validator->fails()) {
            return response()->json(['error' => $validator->errors()], 401);
        }

        $company = Company::where('id', $request->id)->first();

        if($company) {

         $company->delete();

            return response()->json("Done" , 200);
        }


    }

}
