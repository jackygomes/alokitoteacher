<?php

namespace App\Http\Controllers\api;

use App\Http\Controllers\Controller;
use App\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;
use Validator;


class UserController extends Controller
{


    /**
     * Login user and create token
     *
     * @param Request $request
     * @return JsonResponse [string] access_token
     */
    public function login(Request $request)
    {

   $validator = Validator::make($request->all(), [
            'UserName' => 'required',
            'Password' => 'required', 
        ]);

        if ($validator->fails()) {
            return response()->json(['error' => $validator->errors()], 401);
        }

         //return $request->all();
        if (Auth::attempt(['ContactNo' => request('UserName'), 'password' => request('Password')])) {
            $user = Auth::user();

            $success['token'] = $user->createToken('MyApp')->accessToken;
            $success['user'] = Auth::user();
            return response()->json(['success' => $success], 200);
        } else {
            return response()->json(['error' => 'Unauthorised'], 401);
        }
    }


    public function logout(Request $request)
    {
        $request->user()->token()->revoke();

        return response()->json([
            'message' => 'Successfully logged out'
        ]);
    }


    /**
     * Register api
     *
     * @param Request $request
     * @return Response
     */
    public function register(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'FullName' => 'required',
            'Email' => 'required|email|unique:users',
            'ContactNo' =>'required|unique:users',
            'LoginID' => 'required',
            'UserTypeId' => 'required',
            'Theme' => 'required',
            'OrganizationId' => 'required',
            'IsActive' => 'required',
            'Password' => 'required'
        ]);

        if ($validator->fails()) {
            return response()->json(['error' => $validator->errors()], 401);
        }

        $input = $request->all();
        $input['password'] = bcrypt($input['Password']);
   

        $user = User::create($input);

        $success['token'] = $user->createToken('MyApp')->accessToken;
        $success['user'] = $user ;
        return response()->json([$success], 200);
    }

    /**
     * details api
     *
     * @return Response
     */
    public function details()
    {
         $user = Auth::user();
        return response()->json([ $user], 200);
    }

}
