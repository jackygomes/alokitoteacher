<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use Ixudra\Curl\Facades\Curl; 
use Validator;
use Auth;
use Session;
class HomeController extends Controller
{
   

   public $Resdata='';



    /**
     * Create a new controller instance.
     *
     * @return void
     */
    

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('home');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function OrganizationsList()
    {
        return view('organization');
    }

   /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */


 


    public function OrganizationContacts($id)
    {


      $organization=DB::table('organizations')->where('orgID',$id)->first();
         
          $url=url('api/ContactsCategory/'.$organization->org_id);
          $response = Curl::to($url)->get();

          $d=json_decode($response);

          $categories=$d->category;

         // dd(  $categories);

        return view('home.orgProfile',compact('organization','categories'));
    }


 

    public function ContactsDetails(Request $r)
    {
        

      
      $contact=DB::table('persons as p')
      ->select(DB::raw('p.personName,p.phone,p.mobileNo,p.email,p.address,p.picture,d.designationName,c.concernName'))
        ->join('concerns as c','c.concernid','=','p.concernID')
        ->leftJoin('designations as d','d.did','=','p.designationID')
        ->where('p.concernID',$r->catID)
        ->get();
      
      $title=DB::table('concerns')->where('concernid',$r->catID)->first();

 $data='';
      foreach ($contact as $c) {
          $gd="'".json_encode($c)."'";

       $data .= '<li><a href="#" data-person='.$gd.' >'.$c->personName.'<b>, '.$c->designationName.'</b> <span><i>'.($c->mobileNo?$c->mobileNo:'').'</i>'.($c->email?', '.$c->email.'e':'').'</span> </a>'
       .($c->mobileNo?'<label class="message check"><input type="checkbox" value="'.$c->mobileNo.'" name="check"/><span> </span></label>':'')
       .($c->email?'<label class="email check"><input type="checkbox" value="'.$c->email.'" name="email"/><span> </span></label>':'')
       .'</li>';

        }  

 
 
    return response()->json([
                  'title'=>$title->concernName,
                  'data'=>$data
            ], 200) ;



    }

 

    public function menu()
    {
         
 

 $d=self::getChild2(0,2);
 
 return response()->json(['data'=>$this->Resdata], 401) ;
    }





   /*    function getChild($sl=0,$parentID,$res='')
    {


   $concern=DB::table('concerns')->where('parentId',$parentID)->get();
       
echo '<ul>';
       foreach ($concern as $c) {

        if($sl==5){
            echo '<ul><li>'.$c->concernName.'</li></ul>';
        }else{

          echo '<li>'.$c->concernName  .'</li>'; 
        }


                 getChild(5,$c->concernid);

 

            }
echo '</ul>';
     

       }


 

 $d=getChild(0,2);*/





    public function userprofile()
    {
         return view('admin.profile'); 
    }



    public function userprofileAction(Request $r)
    {


switch ($r->action) {
  case 'updateinfo':
    
  $ck = Validator::make($r->all(), [
            'name' => 'required|string|max:255',
            'email' => 'required|string|max:255', 
            'mobile' => 'required', 
        
      ]);
  

       if ($ck->fails()):
       Session::flash('message', array('class' => 'danger','status' => 'Sorry ','text'=>'There was problem with your input !'));
        return redirect()->back()
              ->withErrors($ck)
              ->withInput();
      endif ;



if ($r->hasFile('profilepic')) {

    $directorcust = 'public/asset/profilepic/';
          
      $cp = $r->file('profilepic');
        
        $ex3= $cp->getClientOriginalExtension();
        $rn3 = date('Y-m-d-').str_replace(".","",microtime(true));
        $picture = $rn3 . '.' .$ex3;

        $cp->move($directorcust, $picture);

    if($r->oldpic){
        File::delete('public/asset/profilepic/'.$r->oldpic);
    }
      

      }else{
        $picture=$r->oldpic;

      }

DB::table('users')->where('id',Auth::user()->id)->update([
  'name'=>$r->name,
  'email'=>$r->email,
  'mobile'=>$r->mobile,
  'picture'=>$picture,
]);


  Session::flash('message', array('class' => 'success','status' => 'Success ','text'=>'Information Updated Successfullyt !'));

return redirect()->back();

    # code...
    break;
   case 'resetPassport':
   
      $ck = Validator::make($r->all(), [
            'password' => 'required|string|min:6|confirmed',        
      ]);


       if ($ck->fails()):
       Session::flash('message', array('class' => 'danger','status' => 'Sorry ','text'=>'There was problem with your input !'));
        return redirect()->back()
              ->withErrors($ck)
              ->withInput();
      endif ;


      DB::table('users')->where('id',Auth::user()->id)->update([
        'password'=>bcrypt($r->password),
      ]);

  Session::flash('message', array('class' => 'success','status' => 'Success ','text'=>'Password Updated Successfullyt !'));

return redirect()->back();
     break;
}



    }





}
