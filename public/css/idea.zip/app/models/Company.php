<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class Company extends Model
{
   protected $table = "companies";
   protected $fillable = [
       "PortalUserId",
       "CompanyName",
       "Address",
       "PhoneNumber",
       "ImageFileName",
       "ImageFileId",
       "CreatedDate",
       "MaximumOfficeHours",
       "OfficeOutTime"
   ];
}
