<?php $__env->startSection('content'); ?>
    
        
    <div id="loginbox" class="justify-content-center align-items-center" > 
        
        <div class="authentication-area">
                  
                <div class="logo"><img src="public/assets/img/logo.png" height="50px" /></div>

                <h3 class="title">Authentication</h3>
                <hr class="colorgraph">
             
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
        
                <form name="form" id="form" class="login"  method="POST" action="<?php echo e(url('/login')); ?>"  >
                    <?php echo e(csrf_field()); ?>


 
                      <div class="input-group mb-3">
                          <div class="input-group-prepend"> 
                            <span class="input-group-text"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M3 5v14c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2H5c-1.11 0-2 .9-2 2zm12 4c0 1.66-1.34 3-3 3s-3-1.34-3-3 1.34-3 3-3 3 1.34 3 3zm-9 8c0-2 4-3.1 6-3.1s6 1.1 6 3.1v1H6v-1z"/><path d="M0 0h24v24H0z" fill="none"/></svg></span>
                          </div>
                          <input type="text" value="<?php echo e(old('email')); ?>" name="email" placeholder="ID/ Email"  class="form-control" autocomplete="off">
                        </div>
 
                      <div class="input-group mb-3">
                          <div class="input-group-prepend"> 
                            <span class="input-group-text"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M0 0h24v24H0z" fill="none"/><path d="M12 17c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm6-9h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6h1.9c0-1.71 1.39-3.1 3.1-3.1 1.71 0 3.1 1.39 3.1 3.1v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zm0 12H6V10h12v10z"/></svg></span>
                          </div>
                          <input type="password" value="<?php echo e(old('email')); ?>" name="password" placeholder="Password" class="form-control" autocomplete="off">
                        </div>

  
                        <div class="auth-footer">
                          <a href="<?php echo e(url('register')); ?>">Forgot Password ?</a>
                          <a href="<?php echo e(url('register')); ?>">Sign Up</a>
                              
                              <button type="submit" href="#" class="btn btn-primary float-right" ><i class="glyphicon glyphicon-log-in"></i> Log in</button>                          
                        </div>
                   

                </form>   


        </div>
   
                 

 </div> 

<div id="particles"></div>
 

 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>