<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

Route::group(['prefix' => 'ResourceTracker/RtAccountApi'], function(){

Route::post('login', 'api\UserController@login');
//   url: http://localhost/test/public/ResourceTracker/RtAccountApi/api/login
//   method: post
//    Header:
//    'Content-Type': "application/json"
//    body:
//   Username: your phone no
// password: your password

Route::post('register', 'api\UserController@register');

});
//   url: http://localhost/test/public/ResourceTracker/RtAccountApi/api/register
//   method: post
//    body:
//   name: your name
//   Username: your phone no
//   password: your password
//   c_password: your confirm password


Route::group(['middleware' => 'auth:api', "prefix" => "ResourceTracker/RtAccountApi"], function(){

Route::get('details', 'api\UserController@details');

//   url: http://localhost/test/public/api/details
 //   method: get
//    Header:
//    'Content-Type': "application/json"
//    Authorization : "Bearer your token"


 Route::get('logout', 'api\UserController@logout');

});



Route::group(['middleware' => 'auth:api', "prefix" => "ResourceTracker/RtCompanyApi"], function(){
    Route::post('Save', 'api\CompanyController@create');
    Route::post('UpdateCompany', 'api\CompanyController@update');
    Route::get('GetCompanyByUserId', 'api\CompanyController@details');
    Route::post('Delete', 'api\CompanyController@deleteCompany');
});
