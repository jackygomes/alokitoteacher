<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCompaniesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('companies', function (Blueprint $table) {
            $table->increments('id');
            $table->string('PortalUserId',128);
            $table->string('CompanyName');
            $table->string('Address',300)->nullable();
            $table->string('PhoneNumber',12);
            $table->string('ImageFileName')->nullable();
            $table->string('ImageFileId',100)->nullable();
            $table->timestamp('CreatedDate')->nullable();
            $table->string('MaximumOfficeHours',10)->nullable();
            $table->string('OfficeOutTime',10)->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('companies');
    }
}
