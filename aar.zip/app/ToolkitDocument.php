<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ToolkitDocument extends Model
{
    //
}
