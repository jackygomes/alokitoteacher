<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ToolkitVideo extends Model
{
    //
}
