<?php $__env->startSection('content'); ?>


<div class="container mt-5">
    <div class="row">
        <div class="col-md-4">
            <h1 class="font-weight-bold  mt-5 mb-5">Log In</h1>

                  <form action="<?php echo e(url('login')); ?>" method="POST" class="mb-5">
                    <?php echo e(csrf_field()); ?>

                  <div class="container-fluid">
                    <div class="form-row mb-4">
                      <div class="col-md-12">
                        
                         <input id="email" type="text" class="form-control border-yellow <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" placeholder="Email" autofocus>

                        <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>



                      </div>
                      
                    </div>
                   </div> 
                  <div class="container-fluid">
                    <div class="form-row mt-1">
                      <div class="col-md-12 mb-5">
                        
                        <input id="password" type="password" class="form-control border-yellow <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" value="<?php echo e(old('password')); ?>" required autocomplete="password" placeholder="Password" autofocus>

                        <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

                      </div>
                      
                    </div>
                  </div>

                  <div class="container-fluid">
                    <div class="form-row mt-1">
                      <div class="col-md-12 mb-3">

                      <button type="submit" class="btn background-yellow px-4 py-2 shadow font-weight-bold text-white">Login</button>

                      </div>
                    </div>
                  </div>

                  <div class="container-fluid">
                    <div class="form-row">
                      <div class="col-md-12">

                        <a href="<?php echo e(route('password.request')); ?>" class="font-weight-bold text-yellow">Forgot Your Password ?</a>
                      </div>
                    </div>
                  </div>


                 </form>
     

         </div>

        <div class="col-md-2">
          <div class="m-auto text-center " style="background-color: #f5b82f; width: 100px; height: 100px; border-radius: 50%;">
            <h2 class="text-white" style="padding: 30%;">OR</h2>
          </div>
        </div>
        
        <div class="col-md-4 mr-1 ml-2">
            <h1 class="font-weight-bold my-5">Sign-Up</h1>
            <div>

                <form action="<?php echo e(url('register')); ?>" method="POST" class="mb-5">
                  <?php echo e(csrf_field()); ?>

                  <div class="container-fluid">
                    <div class="form-row mb-4">
                      <div class="col-md-12">
                        

                        <input id="name" type="text" class="form-control border-yellow <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" placeholder="Full Name" autofocus>

                        <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

                      </div>
                      
                    </div>
                   </div>  
                  <div class="container-fluid">
                    <div class="form-row mt-1">
                      <div class="col-md-12 mb-3">

                        <input id="username" type="text" class="form-control border-yellow <?php if ($errors->has('username')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('username'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="username" value="<?php echo e(old('username')); ?>" required autocomplete="username" placeholder="Username" autofocus>

                        <?php if ($errors->has('username')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('username'); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

                      </div>
                      
                    </div>
                  </div>

                  <div class="container-fluid">
                    <div class="form-row mt-1">
                      <div class="col-md-12 mb-3">
                        
                        <input id="email" type="email" class="form-control border-yellow <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" placeholder="Email" autofocus>

                        <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

                      </div>
                      
                    </div>
                  </div>

                  <div class="container-fluid">
                    <div class="form-row mt-1">
                      <div class="col-md-12 mb-3">
                        
                        <input id="phone_number" type="tel" class="form-control border-yellow <?php if ($errors->has('phone_number')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone_number'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="phone_number" value="<?php echo e(old('phone_number')); ?>" required autocomplete="phone_number" placeholder="Phone Ex: 01XXXXXXXXX"  pattern="[0-9]{11}" autofocus>

                        <?php if ($errors->has('phone_number')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone_number'); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

                      </div>
                      
                    </div>
                  </div>

                  <div class="container-fluid">
                    <div class="form-row mt-1">
                      <div class="col-md-12 mb-3">
                        
                        <input id="password" type="password" class="form-control border-yellow <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" value="<?php echo e(old('password')); ?>" required autocomplete="password" placeholder="Password" autofocus>

                        <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

                      </div>
                      
                    </div>
                  </div>
                  <div class="container-fluid">
                    <div class="form-row mt-1">
                      <div class="col-md-12 mb-3">
                        
                        <input id="password_confirmation" type="password" class="form-control border-yellow <?php if ($errors->has('password_confirmation')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password_confirmation'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password_confirmation" value="<?php echo e(old('password_confirmation')); ?>" required autocomplete="password_confirmation" placeholder="Confirm Password" autofocus>

                        <?php if ($errors->has('password_confirmation')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password_confirmation'); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

                      </div>
                      
                    </div>

                  </div>

                  <div class="container-fluid">
                    <div class="form-row mt-1">
                      <div class="col-md-12 mb-3">
                        <div class="form-group">
                          <label>User Type:</label>
                          <select class="form-control border-yellow" name="identifier" required>
                            <option value="" disabled selected>-- Select User Type --</option>
                            <option value="1">Teacher</option>
                            <option value="2">School</option>
                            <option value="3">Parents</option>
                          </select>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div class="container-fluid">
                    <div class="form-row mt-1">
                      <div class="col-md-12 mb-3">
                        <button type="submit" class="mb-5 btn background-yellow text-white px-4 py-2 shadow font-weight-bold " >Signup</button>
                      </div>
                    </div>
                  </div>

                </form>
            </div>

         </div>




    </div>
</div>
   
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rrdv69v1l0mv/AlokitoTeacher/resources/views/auth/login.blade.php ENDPATH**/ ?>