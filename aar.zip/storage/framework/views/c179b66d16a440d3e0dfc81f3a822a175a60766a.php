
<?php $__env->startSection('content'); ?>


<div class="container-fluid">

    <div class="row" style="min-height: 100vh">
      <div class="col-md-2 pt-5 pb-3 text-center" style="background-color: #f5b82f;"><!--left col-->
              
        <div style="width: 150px; height: 150px;" class="mx-auto">
        <?php if(Auth::user()->image == null): ?>
          <i class="fas fa-user-circle fa-10x text-white"></i>
        <?php else: ?>
          <img class="img-fluid rounded-circle h-100 w-100" src="<?php echo e(url('images/profile_picture')); ?>/<?php echo e(Auth::user()->image); ?>">
        <?php endif; ?>
        </div>
         
     
        <form method="post" id="pro_pic_upload_form" action="<?php echo e(url('upload_picture')); ?>" enctype="multipart/form-data">
          <?php echo e(csrf_field()); ?>

          <!-- <div class="form-group mt-3">
            <input type="file" class="text-center center-block mx-auto" name="image">
            <input type="submit" class="btn background-yellow text-white mt-2" value="Upload">
          </div> -->
          <input type="file" name="image" id="profile_picture" class="d-none">
          <button type="button" id="pro_pic_choose" class="btn bg-white mt-2 mb-3">Upload</button>
        </form> 

       

        <h3 class="mt-3 font-weight-bold text-white"><?php echo e(Auth::user()->name); ?></h3>

          <div class="row text-left p-2 mt-3">

            <div class="col-2">
              <i class="fas fa-map-marked-alt"></i>
            </div>
            <div class="col-10">
               <?php if(Auth::user()->location != null): ?> <?php echo e(Auth::user()->location); ?> <?php else: ?> - <?php endif; ?>
            </div>

            <div class="col-2">
              <i class="fas fa-book"></i>
            </div>
            <div class="col-10">
              <?php if(Auth::user()->curriculum != null): ?> <?php echo e(Auth::user()->curriculum); ?> <?php else: ?> - <?php endif; ?>
            </div>

            <div class="col-5 mt-3">
              Class range:
            </div>
            <div class="col-7 mt-3">
              <?php if(Auth::user()->class_range != null): ?> <?php echo e(Auth::user()->class_range); ?> <?php else: ?> - <?php endif; ?>
            </div>

          </div>

       

          <div class="row text-left p-2 mt-3">
            <div class="col-2">
              <i class="fas fa-envelope"></i>
            </div>
            <div class="col-10">
              <?php echo e(Auth::user()->email); ?>

            </div>
            <div class="col-2">
              <i class="fas fa-phone"></i>
            </div>
            <div class="col-10">
              <?php echo e(Auth::user()->phone_number); ?>

            </div>
            
          </div>


       

         <h4 class="mt-3">Current Balance </h4>
         <p>৳<?php echo e(round(Auth::user()->balance, 2)); ?></p>
         <div class="">
            <button type="button" class=" btn btn-success btn-sm"style="display: inline-block" >Deposit</button>
            <button type="button" class="  btn btn-danger btn-sm">Withdraw</button>
         </div>


         
     </div>

    <div class="col-md-8 pt-5"  style="background-color: #f3f2f0;">
      <div class="container-fluid ">
        <h3 class="font-weight-bold" >Basic Info</h3>
        <hr>

        <form class="mt-3" method="POST" action="<?php echo e(route('updateInfo')); ?>">
          <?php echo csrf_field(); ?>

          <?php if(session()->has('successInfo')): ?>
            <div class="alert alert-success">
                <?php echo e(session()->get('successInfo')); ?>

            </div>
          <?php endif; ?>

          <div class="form-group row">
              <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Name')); ?></label>

              <div class="col-md-6">
                  <input id="name" type="text" class="form-control border-yellow <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="name" value="<?php echo e(Auth::user()->name); ?>" required autocomplete="name" autofocus>

                  <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                      <span class="invalid-feedback" role="alert">
                          <strong><?php echo e($message); ?></strong>
                      </span>
                  <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
              </div>
          </div>

          <div class="form-group row">
              <label for="phone_number" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Phone Number')); ?></label>

              <div class="col-md-6">
                  <input id="phone_number" type="tel" class="form-control border-yellow <?php if ($errors->has('phone_number')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone_number'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="phone_number" value="<?php echo e(Auth::user()->phone_number); ?>" placeholder="Phone Ex: 01XXXXXXXXX" pattern="[0-9]{11}" required autocomplete="phone_number" autofocus>

                  

                  <?php if ($errors->has('phone_number')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone_number'); ?>
                      <span class="invalid-feedback" role="alert">
                          <strong><?php echo e($message); ?></strong>
                      </span>
                  <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
              </div>
          </div>

          <div class="form-group row">
              <label for="location" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Location')); ?></label>

              <div class="col-md-6">
                  <input id="location" type="text" class="form-control border-yellow <?php if ($errors->has('location')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('location'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="location" value="<?php echo e(Auth::user()->location); ?>" required autocomplete="location" autofocus>

                  <?php if ($errors->has('location')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('location'); ?>
                      <span class="invalid-feedback" role="alert">
                          <strong><?php echo e($message); ?></strong>
                      </span>
                  <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
              </div>
          </div>


          <?php if(Auth::user()->identifier == 2): ?>

          <div class="form-group row">
              <label for="curriculum" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Curriculumn')); ?></label>

              <div class="col-md-6">
                  <input id="curriculum" type="text" class="form-control border-yellow <?php if ($errors->has('curriculum')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('curriculum'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="curriculum" value="<?php echo e(Auth::user()->curriculum); ?>" required autocomplete="curriculum" autofocus>

                  <?php if ($errors->has('curriculum')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('curriculum'); ?>
                      <span class="invalid-feedback" role="alert">
                          <strong><?php echo e($message); ?></strong>
                      </span>
                  <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
              </div>
          </div>

          <div class="form-group row">
              <label for="class_range" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Class Range')); ?></label>

              <div class="col-md-6">
                  <input id="class_range" type="text" class="form-control border-yellow <?php if ($errors->has('class_range')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('class_range'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="class_range" value="<?php echo e(Auth::user()->class_range); ?>" required autocomplete="class_range" autofocus>

                  <?php if ($errors->has('class_range')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('class_range'); ?>
                      <span class="invalid-feedback" role="alert">
                          <strong><?php echo e($message); ?></strong>
                      </span>
                  <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
              </div>
          </div>

          <div class="form-group row">
              <label for="no_of_student" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Number of Students')); ?></label>

              <div class="col-md-6">
                  <input id="students" type="text" class="form-control border-yellow <?php if ($errors->has('no_of_student')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('no_of_student'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="no_of_student" value="<?php echo e(Auth::user()->no_of_student); ?>" required autocomplete="no_of_student" autofocus>

                  <?php if ($errors->has('no_of_student')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('no_of_student'); ?>
                      <span class="invalid-feedback" role="alert">
                          <strong><?php echo e($message); ?></strong>
                      </span>
                  <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
              </div>
          </div>

          <div class="form-group row">
              <label for="no_of_teacher" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Number of Teachers')); ?></label>

              <div class="col-md-6">
                  <input id="no_of_teacher" type="text" class="form-control border-yellow <?php if ($errors->has('no_of_teacher')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('no_of_teacher'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="no_of_teacher" value="<?php echo e(Auth::user()->no_of_teacher); ?>" required autocomplete="no_of_teacher" autofocus>

                  <?php if ($errors->has('no_of_teacher')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('no_of_teacher'); ?>
                      <span class="invalid-feedback" role="alert">
                          <strong><?php echo e($message); ?></strong>
                      </span>
                  <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
              </div>
          </div>

          <div class="form-group row">
              <label for="founded" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Founded')); ?></label>

              <div class="col-md-6">
                  <input id="founded" type="text" class="datepicker form-control border-yellow <?php if ($errors->has('founded')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('founded'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="founded" value="<?php echo e(Auth::user()->founded); ?>" required autocomplete="founded" autofocus>

                  <?php if ($errors->has('no_of_teachers')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('no_of_teachers'); ?>
                      <span class="invalid-feedback" role="alert">
                          <strong><?php echo e($message); ?></strong>
                      </span>
                  <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
              </div>
          </div>

          <?php endif; ?>

         


          

          <div class="form-group row mb-0">
            <div class="col-md-6 offset-md-4">
                <button type="submit" class="btn background-yellow">
                    <?php echo e(__('Update Info')); ?>

                </button>
            </div>
          </div>
      </form>



      <h3 class="font-weight-bold mt-5" >Change Password</h3>
      <hr>

      <form class="mt-3" method="POST" action="<?php echo e(route('updatePassword')); ?>">
        <?php echo csrf_field(); ?>

        <?php if(session()->has('successPassword')): ?>
            <div class="alert alert-success">
                <?php echo e(session()->get('successPassword')); ?>

            </div>
        <?php endif; ?>

        <div class="form-group row">
            <label for="current_password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Current Password')); ?></label>

            <div class="col-md-6">
                <input id="current_password" type="password" class="form-control border-yellow <?php if ($errors->has('current_password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('current_password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="current_password" placeholder="Enter your current password" required autocomplete="current-password">

                <?php if ($errors->has('current_password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('current_password'); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>
        </div>

        <div class="form-group row">
            <label for="password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('New Password')); ?></label>

            <div class="col-md-6">
                <input id="password" type="password" class="form-control border-yellow <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" required placeholder="Enter new password" autocomplete="new-password">

                <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>
        </div>

        <div class="form-group row">
            <label for="password-confirm" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Confirm New Password')); ?></label>

            <div class="col-md-6">
                <input id="password-confirm" type="password" class="form-control border-yellow" name="password_confirmation" required placeholder="Confirm new password" autocomplete="new-password">
            </div>
        </div>

        <div class="form-group row mb-0">
          <div class="col-md-6 offset-md-4">
              <button type="submit" class="btn background-yellow">
                  <?php echo e(__('Change Password')); ?>

              </button>
          </div>
        </div>


      </form>




        
      </div>



      


      </div> <!-- 2nd col ends here -->

      <div class="col-md-2 pt-3" style="border-left: 1px solid #e0e0e0; background-color: #f3f2f0;">
      </div>





   </div><!-- row ends here -->


  

</div>

 <?php $__env->startPush('js'); ?>

    <script type="text/javascript">
      $('#pro_pic_choose').on('click', function () {
          $("#profile_picture").click();
      });
      $("#profile_picture").change(function () {
        $("#pro_pic_upload_form").submit();
      });
    </script>

<?php $__env->stopPush(); ?>

  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rrdv69v1l0mv/AlokitoTeacher/resources/views/settings_school.blade.php ENDPATH**/ ?>