<?php echo e($slot); ?>

<?php /**PATH /home/rrdv69v1l0mv/AlokitoTeacher/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>