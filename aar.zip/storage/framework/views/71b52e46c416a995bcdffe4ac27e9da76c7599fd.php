<div class="col-md-2 pt-3" style="border-left: 1px solid #e0e0e0; background-color: #f3f2f0;">

	<h4 class="mb-3 text-center">Leaderboard <small><a class="text-yellow" id="popover" title="How does leaderboard work?" data-content="Leaderboard is based on rating. Rating is calculated based on marks gained in tests of Courses/Toolkits and on rating of teacher's own courses." data-trigger="hover"><i class="fas fa-question-circle"></i></a></small></h4>
	<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<a class="card p-2 mb-2 border-yellow" href="<?php echo e(url('t')); ?>/<?php echo e($user->username); ?>">
		<div class="row">
		  	<div class="col-4 my-auto">
		      <?php if($user->image == null): ?>
		        <img class="img-fluid rounded-circle" style="max-height: 50px;" src="<?php echo e(url('images/profile_picture')); ?>/default-profile-picture.png">
		      <?php else: ?>
		        <img class="img-fluid rounded-circle" style="max-height: 50px;" src="<?php echo e(url('images/profile_picture')); ?>/<?php echo e($user->image); ?>">
		      <?php endif; ?>
		    </div>
		    <div class="col-6 text-yellow font-weight-bold my-auto" ><?php echo e($user->name); ?></div>

		    <div class="col-2 my-auto" style="padding-right: 0px !important; padding-left: 0px !important;"><?php if($key <= 2): ?> <i class="fas fa-trophy" style="color: <?php if($key == 0): ?> #d4af37 <?php elseif($key == 1): ?> #aaa9ad <?php elseif($key == 2): ?> #cd7f32 <?php else: ?> #fff <?php endif; ?>"></i><?php endif; ?></div>
		        
		</div>
	</a>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div><?php /**PATH F:\xampp\htdocs\AlokitoTeacher\resources\views/leaderboard.blade.php ENDPATH**/ ?>