<?php $__env->startSection('content'); ?>


<div class="container-fluid" style="min-height: 100vh">
	<div class="row">
		<div class="col-md-2 sidebar-job-all" style="background-color: #f5b82f;">
			
			<a href="<?php echo e(url('jobs/all')); ?>" class="btn bg-white form-control mt-5 <?php echo e(request()->route('type') == 'all' ? 'job-button-active' : ''); ?>">All Jobs</a>
			<a href="<?php echo e(url('jobs/saved')); ?>" class="btn bg-white form-control mt-3 <?php echo e(request()->route('type') == 'saved' ? 'job-button-active' : ''); ?>">Saved Jobs</a>

	

			<h3 class="font-weight-bold mt-5 text-white">Filter</h3>
			<hr>
			<select class="form-control border-yellow" id="location" required>
				<option value="" disabled="" selected="">-- Location --</option>
				<?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<option value="<?php echo e($location->location); ?>"><?php echo e($location->location); ?></option>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</select>
			<br>
			<select class="form-control border-yellow mb-3" id="school" required>
				<option value="" disabled="" selected="">-- School --</option>
				<?php $__currentLoopData = $schools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $school): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<option value="<?php echo e($school->id); ?>"><?php echo e($school->name); ?></option>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</select>
		
		</div>

		<div class="col-md-8" style="background-color: #f3f2f0;">
			
			<div class="container mt-3">
				<?php if(session()->has('success')): ?>
		            <div class="alert alert-success">
		                <?php echo e(session()->get('success')); ?>

		            </div>
		        <?php endif; ?>
				<div class="row">
					<div class="col-8 col-md-10">
					  <input class="form-control" id="search" type="text" placeholder="Search For Job..">
					</div>

					<div class="col-4 col-md-2">
					  <button id="searchButton" class="btn background-yellow mb-2 float-right w-100">Search</button>
					</div>
				</div>
			  	<br>

			  	<div id="table">
					<table class="table table-bordered">
					    <thead>
					      <tr>
					        <th class="font-weight-bold">
					        	<span>Sort By:</span>
					        	<a class="ml-5 text-yellow" href=" ">Recent</a>
					        	<a class="ml-5" href="#">Popular</a>
					        	<!-- <a href="#" class="text-dark ml-5">Salary</a>  -->
					        </th>
					        
					      </tr>
					    </thead>
					    	<tbody id="myTable">
					    		<?php $__currentLoopData = $job_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v_job_info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
							      	<tr id="job_<?php echo e($v_job_info->job_id); ?>">
							        	<td class="bg-white">
							        		<div class="container-fluid">
							        			<div class="row">
							        				<div class="col-md-2 text-center">
							        					<?php if($v_job_info->image == null): ?>
											          		<i class="fas fa-user-circle fa-5x text-yellow"></i>
												        <?php else: ?>
												        <div class="mx-auto" style="width: 70px; height: 70px;">
												          <img class="img-fluid rounded-circle h-100 w-100" src="<?php echo e(url('images/profile_picture')); ?>/<?php echo e($v_job_info->image); ?>">
												        </div>
												        <?php endif; ?>

												        <h4 class="font-weight-bold mt-3"><a class="text-yellow" href="<?php echo e(url('s')); ?>/<?php echo e($v_job_info->username); ?>"> <?php echo e($v_job_info->name); ?></a></h4>
									        		</div>


								        			<div class="col-md-7">
								        				<span class="font-weight-bold">Job Positon: <?php echo e($v_job_info->job_title); ?></span><br>

										        		<span class="font-weight-bold">Salary Range:</span><span> <?php echo e($v_job_info->expected_salary_range); ?></span><br> 

										        		<span class="font-weight-bold">Type:</span><span><?php if($v_job_info->nature == 1): ?> Permanent <?php elseif($v_job_info->nature == 2): ?> Part-Time  <?php elseif($v_job_info->nature == 3): ?> Contractual <?php else: ?> - <?php endif; ?></span><br>

										        		<span class="font-weight-bold">Vacancy:</span><span> <?php echo e($v_job_info->vacancy); ?></span><br>

										        		<span class="font-weight-bold" >Description:</span> 
										        		
										        		<?php echo e(str_limit(strip_tags($v_job_info->description), 150)); ?>

											            
											              <a href="<?php echo e(url('job_detail')); ?>/<?php echo e($v_job_info->job_id); ?>" class="text-yellow">Read More</a>
											            
											            
								        			</div>

								        			<div class="col-md-3">
								        				<small>
								        				Published: <?php echo e(date("jS F, Y", strtotime($v_job_info->created_at))); ?></small>
								        				<br>
								        				<small class="text-danger">
								        				Deadline: <?php echo e(date("jS F, Y", strtotime($v_job_info->deadline))); ?></small>
								        				<br>
								        				
								        				<button type="button" value="<?php echo e($v_job_info->job_id); ?>" class="btn btn-success applyButton" data-toggle="modal" data-target="#coverLetterModal">Apply</button>
								        				<?php if(request()->route('type') == 'all'): ?> 
								        				<button type="button" value="<?php echo e($v_job_info->job_id); ?>" class="btn border-yellow saveButton">Save</button>
								        				<?php else: ?>
								        				<button type="button" value="<?php echo e($v_job_info->job_id); ?>" class="btn btn-danger removeButton">Remove</button>
								        				<?php endif; ?>
								        			</div>
							        			</div>
							        		</div> 
							        	 </td>
							      	</tr>
						    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
						    </tbody>
				    </table>

			  		<div class="mt-5">
			           <?php echo e($job_info->links()); ?>

			        </div>
			    </div>
			</div>
		</div>

		<?php echo $__env->make('leaderboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</div>
</div>

<!-- Modal -->
<div class="modal fade" id="coverLetterModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="modalLongTitle">Your Profile will be shared with the school as your CV. Would you like to add a cover letter to increase your chances of being selected ?</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" id="modalBody">

      	<form method="POST" id="coverLetterForm" action="<?php echo e(url('submit_cover_letter')); ?>">
      		 <?php echo e(csrf_field()); ?>

      		<div class="form-group">
			  <textarea class="form-control" rows="10" id="coverLetterText" name="cover_letter" placeholder="Write Cover Letter Here"></textarea>
			</div>
			<input type="hidden" name="job_id">
			<button type="submit" id="coverLetterSubmitButton" class="btn background-yellow float-right">Submit</button>
      		
      	</form>

  		  	

      </div>
    
    </div>
  </div>
</div>

<div class="toast toast-success" role="alert" id="toastSuccess" data-autohide="true" data-animation="true" data-delay="3000">  
      
    <div class="toast-body"> 
        Job is saved. 
        <button type="button" class="ml-2 mb-1 close" data-dismiss="toastSuccess" aria-label="Close"> 
            <span aria-hidden="true">×</span> 
        </button> 
    </div> 
</div>

<div class="toast toast-danger" role="alert" id="toastDanger" data-autohide="true" data-animation="true" data-delay="3000">  
      
    <div class="toast-body"> 
        Job is removed. 
        <button type="button" class="ml-2 mb-1 close" data-dismiss="toastDanger" aria-label="Close"> 
            <span aria-hidden="true">×</span> 
        </button> 
    </div> 
</div>



 <?php $__env->startPush('js'); ?>

    <script type="text/javascript">
    	
		$(document).ready(function(){
			$('.applyButton').on('click', function () {
	    		verify_applied_job($(this).val());
			});

			$('.saveButton').on('click', function () {
	    		save_job($(this).val());
			});

			$('.removeButton').on('click', function () {
	    		remove_saved_job($(this).val());
			});

			

		});

		$('#searchButton').on('click', function () {
			search_filter($('#search').val(), $('#location').val(), $('#school').val());
		});
		$('#location').on('change', function (e) {
			search_filter($('#searchButton').val(), this.value, $('#school').val());
		});
		$('#school').on('change', function (e) {
			search_filter($('#searchButton').val(), $('#location').val(), this.value);
		});

		$(document).on('click','#ajaxPagination a',function(e){
            e.preventDefault();
            pagination($(this).attr('href')); 
            return false;
        });

        function pagination(url){
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
              });
              jQuery.ajax({
                url: url,
                success: function(result){
                    jQuery('#table').html(result);
                }
            });
        }

        function search_filter(search, location, school){
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
              });
              jQuery.ajax({
                url: "<?php echo e(url('/search_filter_jobs')); ?>",
                method: 'get',
                data: {
                   search: search,
                   location : location,
                   school : school,
                },
                success: function(result){
                    jQuery('#table').empty().html(result);
                }
            });
        }

        function verify_applied_job(job_id){
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
              });
              jQuery.ajax({
                url: "<?php echo e(url('/verify_applied_job')); ?>",
                method: 'POST',
                data: {
                   job_id: job_id,
                },
                success: function(result){
                	if(result == 'success'){
                		jQuery('#modalLongTitle').text('Error');
                		jQuery('#modalBody').html('<h3 class="text-center text-danger">Already Applied for this Job</h3>');	
                	}else{
                		jQuery('#modalLongTitle').text('Your Profile will be shared with the school as your CV. Would you like to add a cover letter to increase your chances of being selected ?');
                		jQuery('#modalBody').html('<form method="POST" action="<?php echo e(url('submit_cover_letter')); ?>"><?php echo e(csrf_field()); ?><div class="form-group"><textarea class="form-control" rows="10" id="coverLetterText" name="cover_letter" placeholder="Write Cover Letter Here"></textarea></div><input type="hidden" name="job_id" value="'+job_id+'"><button type="submit" id="coverLetterSubmitButton" class="btn background-yellow float-right">Submit</button></form>');
                	}
                    
                }
            });
          }

          function save_job(job_id){
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
              });
              jQuery.ajax({
                url: "<?php echo e(url('/save_job')); ?>",
                method: 'POST',
                data: {
                   job_id: job_id,
                },
                success: function(result){
                	if(result == 'success'){
                		$('#toastSuccess').toast('show');
                	}
                    
                }
            });
          }

          function remove_saved_job(job_id){
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
              });
              jQuery.ajax({
                url: "<?php echo e(url('/remove_saved_job')); ?>",
                method: 'POST',
                data: {
                   job_id: job_id,
                },
                success: function(result){
                	if(result == 'success'){
                		$('#job_'+job_id).remove();
                		$('#toastDanger').toast('show');
                	}
                    
                }
            });
          }

     
    </script>

<?php $__env->stopPush(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\AlokitoTeacher\resources\views/all-jobs.blade.php ENDPATH**/ ?>