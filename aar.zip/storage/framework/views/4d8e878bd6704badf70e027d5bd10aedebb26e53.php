
<?php $__env->startSection('content'); ?>


<div class="container-fluid">

    <div class="row">
      <div class="col-md-2 col-sm-12 pt-5 pb-3 text-center" style="background-color: #f5b82f;"><!--left col-->
              
        <div style="width: 150px; height: 150px;" class="mx-auto">
        <?php if($user_info->image == null): ?>
          <i class="fas fa-user-circle fa-10x text-white"></i>
        <?php else: ?>
          <img class="img-fluid rounded-circle h-100 w-100" src="<?php echo e(url('images/profile_picture')); ?>/<?php echo e($user_info->image); ?>">
        <?php endif; ?>
        </div>

        <?php if($user_info->id == Auth::id()): ?>
     
        <form method="post" id="pro_pic_upload_form" action="<?php echo e(url('upload_picture')); ?>" enctype="multipart/form-data">
          <?php echo e(csrf_field()); ?>

          <!-- <div class="form-group mt-3">
            <input type="file" class="text-center center-block mx-auto" name="image">
            <input type="submit" class="btn background-yellow text-white mt-2" value="Upload">
          </div> -->
          <input type="file" name="image" id="profile_picture" class="d-none">
          <button type="button" id="pro_pic_choose" class="btn bg-white mt-2 mb-3">Upload</button>
        </form>

         <a href="<?php echo e(url('settings')); ?>" class="text-dark float-right mt-3"><i class="fas fa-pen" ></i> <small>Edit Details</small></a>

        <?php endif; ?>


        <h3 class="mt-5 font-weight-bold text-white"> <?php echo e($user_info->name); ?></h3>

        <?php for($i = 1; $i <= 5; $i++): ?>
          <?php if($user_info->rating - $i >= 0): ?>
          <i class="fa fa-star" aria-hidden="true"></i>
          <?php else: ?>
          <i class="far fa-star text-white"></i>
          <?php endif; ?>
        <?php endfor; ?>

        <div class="row text-left p-2 mt-3">
          <div class="col-12">
            Recent Status:
          </div>
          <div class="col-2">
            <i class="fas fa-graduation-cap"></i>
          </div>
          <div class="col-10">
            <?php if($recent_institute != null): ?> <?php echo e($recent_institute->institute); ?> <?php else: ?> - <?php endif; ?>
          </div>

          <div class="col-2">
            <i class="fas fa-briefcase"></i>
          </div>
          <div class="col-10">
            <?php if($recent_work != null): ?> <?php echo e($recent_work->institute); ?> <?php else: ?> - <?php endif; ?>
          </div>

          <div class="col-2">
            <i class="fas fa-user-tie"></i>
          </div>
          <div class="col-10">
            <?php if($recent_work != null): ?> <?php echo e($recent_work->position); ?> <?php else: ?> - <?php endif; ?>
          </div>

          <div class="col-2 mt-3">
            <i class="fas fa-birthday-cake"></i>
          </div>
          <div class="col-10 mt-3">
            <?php if($user_info->date_of_birth != null): ?> <?php echo e(date("jS F, Y", strtotime($user_info->date_of_birth))); ?> <?php else: ?> - <?php endif; ?>
          </div>
        </div>

        <?php if($user_info->id == Auth::id()): ?>

        <div class="row text-left p-2 mt-3">
          <div class="col-2">
            <i class="fas fa-envelope"></i>
          </div>
          <div class="col-10">
            <?php echo e($user_info->email); ?>

          </div>
          <div class="col-2">
            <i class="fas fa-phone"></i>
          </div>
          <div class="col-10">
            <?php echo e($user_info->phone_number); ?>

          </div>
          
        </div>


       

         <h4 class="mt-3">Current Balance </h4>
         <p><?php echo e(round($user_info->balance, 2)); ?></p>
         <div class="">
            <button type="button" class=" btn btn-success btn-sm"style="display: inline-block" >Deposit</button>
            <button type="button" class="  btn btn-danger btn-sm">Withdraw</button>
         </div>
         <?php endif; ?>

         
     </div>

    <div class="col-md-8 col-sm-12 mt-5">
      <div class="container-fluid ">

        <?php if(session()->has('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session()->get('success')); ?>

            </div>
        <?php endif; ?>

        <?php if(session()->has('danger')): ?>
            <div class="alert alert-danger">
                <?php echo e(session()->get('danger')); ?>

            </div>
        <?php endif; ?>


        <h3 class="font-weight-bold" >Achievements</h3>
        <div class="row">
          <div class="col-sm-12 mt-2">
            <h4 class="font-weight-bold text-yellow mb-3">Course</h4><hr>

            <?php
            $no_achievement = true;
            ?>

            <?php $__currentLoopData = $achievements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $achievement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <?php if($achievement->total_quizzes != 0 && $achievement->completed_quizzes != 0): ?>

            <?php
            $no_achievement = false;
              $percentage = round((($achievement->gained_points/($achievement->total_questions * 2)) * 100), 1);
            ?>

            <i class="fas fa-medal fa-2x mr-2" style=" color:
            <?php if($percentage >= 85): ?>
            #d4af37;
            <?php elseif($percentage >= 75 && $percentage <= 84): ?>
            #aaa9ad;
            <?php elseif($percentage >= 65 && $percentage <= 74): ?>
            #cd7f32;
            <?php elseif($percentage >= 50 && $percentage <= 64): ?>
            #00a74a;
            <?php else: ?>
            #ff4f4f;
            <?php endif; ?>
            ">
             
            </i>
            <h5 style="display: inline-block"><?php echo e($achievement->title); ?></h5>

            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php if($no_achievement == true): ?>
            <h5 class="text-center text-muted">No Achievements to Show</h5>
            <?php endif; ?>
            
          </div>
        </div>
      </div>



      <?php if($user_info->id == Auth::id()): ?>
      <?php
      $no_progress = true;
      ?>
      <div class="container-fluid mt-5">
        <div class="row">
          <div class="col-sm-12"> 
              <h3 class="font-weight-bold" >Course Learning Progress</h3>
                <div class="table-responsive-sm">
                  <table class="table ">
                    <thead>
                      <tr>
                        <th style="width:40%">Course</th>
                        <th style="width:40%">Progress</th>
                        <!-- <th style="width:10%">Current Grade</th> -->
                        <th style="width:20%">Date</th>
                      </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $progresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $progress): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        <?php if($progress->completed_quizzes != 0 && $progress->total_quizzes != 0): ?>

                        <?php
                        $no_progress = false;
                        ?>
                        <tr>
                          <td><?php echo e($progress->title); ?></td>
                          <td>
                            <div class="progress">
                              <div class="progress-bar background-yellow" style="width: <?php echo e(round((($progress->completed_quizzes/$progress->total_quizzes)*100), 1)); ?>%;"><?php echo e(round((($progress->completed_quizzes/$progress->total_quizzes)*100), 1)); ?>%
                              </div>
                            </div>
                            
                          </td>
                         <!--  <td><?php echo e(($progress->completed_quizzes/$progress->total_quizzes)*100); ?>%</td> -->
                          <td><?php echo e(date("jS F, Y", strtotime($progress->updated_at))); ?></td>
                        </tr>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      

                                
                    </tbody>
                  </table>

                  <?php if($no_progress == true): ?>
                  <h5 class="text-center text-muted">No Progress to Show</h5>
                  <?php endif; ?>

                </div>
            </div>
          </div>
      </div>
      <?php endif; ?>
   



          <div class="container-fluid">
            <div class="row">
                <div class=" mt-5 col-sm-12">
                   <h3 class="font-weight-bold mr-3" style="display: inline-block">Work Expereince</h3>
                   
                   <?php if($user_info->id == Auth::id()): ?>
                   <span class="fa-clickable" data-toggle="modal" data-target="#workExperience"><i class="fas fa-pen" ></i> <small>Add</small></span>
                   <?php endif; ?>

                    <div class="mr=2">
                      <div class="table-responsive-sm">
                        <table class="table ">
                          <thead>
                            <tr>
                              <th style="width:20%">Institute</th>
                              <th style="width:10%">Position</th>
                              <th style="width:20%">From</th>
                              <th style="width:20%">To</th>
                              <?php if($user_info->id == Auth::id()): ?>
                               <th style="width:10%">Action</th>
                              <?php endif; ?>
                            </tr>
                          </thead>
                          <tbody>
                             <?php $__currentLoopData = $work_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                              <td><?php echo e($work->institute); ?></td>
                              <td><?php echo e($work->position); ?></td>
                              <td><?php echo e(date("jS F, Y", strtotime($work->from_date))); ?></td>
                              <td><?php echo e($work->to_date == '0000-00-00'? 'Currently Working' : date("jS F, Y", strtotime($work->to_date))); ?></td>
                              <?php if($user_info->id == Auth::id()): ?>
                              <td><a href="<?php echo e(url('remove')); ?>/work_experience/<?php echo e($work->id); ?>" class="btn btn-danger btn-sm">Remove</a></td>
                              <?php endif; ?>
                              
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </tbody>
                        </table>
                        <?php if($work_info->count() == 0): ?>
                          <h5 class="text-center text-muted">No Work Experience to Show</h5>
                        <?php endif; ?>

                       </div>
                    </div>

                            
              
              </div>
            </div>
          </div>

              

        <div class="container-fluid">
          <div class="row">
              
            <div class="col-sm-12">
                 
                <h3 class="font-weight-bold mt-5 mr-3" style="display: inline-block">Academics</h3>

                <?php if($user_info->id == Auth::id()): ?>
                <span class="fa-clickable" data-toggle="modal" data-target="#academics"><i class="fas fa-pen" ></i> <small>Add</small></span>
                <?php endif; ?>

                <div class="mr=2">
                    <div class="table-responsive-sm">
                    <table class="table ">
                      <thead>
                        <tr>
                          <th style="width:15%">Exam Type</th>
                          <th style="width:15%">Result</th>
                          <th style="width:20%">Institute</th>
                          <th style="width:10%">Passing Year</th>
                          <th style="width:10%">CGPA/GPA</th>
                          <th style="width:20%">Date</th>
                          <?php if($user_info->id == Auth::id()): ?>
                           <th style="width:10%">Action</th>
                          <?php endif; ?>
                        </tr>
                      </thead>
                      <tbody>
                         <?php $__currentLoopData = $academic_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $academic_info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>

                          <td><?php echo e($academic_info->exam_type); ?></td>
                          <td>
                            <div class="progress">
                                    <div class="progress-bar" role="progressbar" style="width: <?php echo e($academic_info->result); ?>%; background-color:#FE980F" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"><?php echo e($academic_info->result); ?>%</div>
                                </div>
                            
                                    </td>
                                    <td><?php echo e($academic_info->institute); ?></td>
                                    <td><?php echo e(date("Y", strtotime($academic_info->passing_year))); ?>

                                    <td><?php echo e($academic_info->cgpa); ?></td>
                                    <td><?php echo e(date("jS F, Y", strtotime($academic_info->date))); ?></td>

                                    <?php if($user_info->id == Auth::id()): ?>
                                    <td><a href="<?php echo e(url('remove')); ?>/academic/<?php echo e($academic_info->id); ?>" class="btn btn-danger btn-sm">Remove</a></td>
                                    <?php endif; ?>

                                  </tr>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                              </table>

                              <?php if($academic_info->count() == 0): ?>
                                <h5 class="text-center text-muted">No Academic Info to Show</h5>
                              <?php endif; ?>
                      </div>
              </div>
            </div>
          </div>
        </div>




      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-12"> 
            <h3 class="font-weight-bold mt-5" style="display: inline-block">Subject Based Knowledge</h3>
            <div class="mr=2">
              <div class="table-responsive-sm">
                <table class="table ">
                  <thead>
                    <tr>
                      <th style="width:20%">Course</th>
                      <th style="width:40%">Progress</th>
                      <th style="width:10%">Current Grade</th>
                      <th style="width:20%">Date</th>
                    </tr>
                    </thead>
                    <tbody>
                      <?php $__currentLoopData = $course_knowledges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course_knowledge): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td><?php echo e($course_knowledge->subject_name); ?></td>
                        <td>
                          <div class="progress">
                            <div class="progress-bar background-yellow" role="progressbar" style="width: <?php echo e(round((($course_knowledge->gained_points/($course_knowledge->total_questions * 2))*100), 1)); ?>%;"><?php echo e(round((($course_knowledge->gained_points/($course_knowledge->total_questions * 2))*100), 1)); ?>%</div>
                          </div>
                        </td>
                        <td><?php echo e(round((($course_knowledge->gained_points/($course_knowledge->total_questions * 2))*100), 1)); ?>%</td>
                        <td><?php echo e(date("jS F, Y", strtotime($course_knowledge->updated_at))); ?></td>


                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>

                <?php if($course_knowledges == null): ?>
                  <h5 class="text-center text-muted">No Subject Based Knowledge to Show</h5>
                <?php endif; ?>
              </div>
          </div>
        </div>
      </div>
    </div>


       
        <div class="container-fluid mb-5">
          <div class="row">

            <div class="col-sm-12">
              <h3 class="font-weight-bold mt-5 mr-3" style="display: inline-block">Skills</h3>
              <?php if($user_info->id == Auth::id()): ?>
              <span class="fa-clickable" data-toggle="modal" data-target="#skills"><i class="fas fa-pen" ></i> <small>Add</small></span>
              <?php endif; ?>
                <div class="mr=2">
                    <div class="table-responsive-sm">
                        <table class="table ">
                          <thead>
                            <tr>
                              <th style="width:15%">Training Title</th>
                              <th style="width:15%">Topic</th>
                              <th style="width:15%">Institute</th>
                              <th style="width:15%">Country</th>
                              <th style="width:15%">Location</th>
                              <th style="width:5%">Year</th>
                              <th style="width:10%">Duration</th>
                              <?php if($user_info->id == Auth::id()): ?>
                              <th style="width:10%">Action</th>
                              <?php endif; ?>

                            </tr>
                          </thead>
                          <tbody>
                            <?php $__currentLoopData = $skill_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v_skill_info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                              <td><?php echo e($v_skill_info->training_title); ?></td>
                              <td><?php echo e($v_skill_info->topic); ?></td>
                              <td><?php echo e($v_skill_info->institute); ?></td>
                              <td><?php echo e($v_skill_info->country); ?></td>
                              <td><?php echo e($v_skill_info->location); ?></td>
                              <td><?php echo e(date("Y", strtotime($v_skill_info->year))); ?></td>
                              <td><?php echo e($v_skill_info->duration); ?></td>

                              <?php if($user_info->id == Auth::id()): ?>
                              <td><a href="<?php echo e(url('remove')); ?>/skill/<?php echo e($v_skill_info->id); ?>" class="btn btn-danger btn-sm">Remove</a></td>
                              <?php endif; ?>

                            </tr>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </tbody>
                          </table>

                          <?php if($skill_info->count() == 0): ?>
                            <h5 class="text-center text-muted">No Skill to Show</h5>
                          <?php endif; ?>

                      </div>
              </div>
            </div>
          </div>
        </div>


      </div> <!-- 2nd col ends here -->

        <?php echo $__env->make('leaderboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>





   </div><!-- row ends here -->


  

</div>



<!-- Add work experience Modal -->
<div class="modal fade" id="workExperience" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title">Add Work Experience</h1>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" >

        <form method="POST" action="<?php echo e(url('add_work_experience')); ?>">
           <?php echo e(csrf_field()); ?>

          <div class="form-group">
            <input type="text" class="form-control border-yellow" name="institute" placeholder="Name of the institute" required>
          </div>
          <div class="form-group">
            <input type="text" class="form-control border-yellow" name="position" placeholder="Your position there" required>
          </div>
          <div class="form-group row">
            <div class="col-6">
              <label>From</label>
              <input type="text" class="datepicker form-control border-yellow" name="from" placeholder="Starting Date" required>
            </div>
            <div class="col-6">
              <label>To</label>
              <input type="text" class="datepicker form-control border-yellow" id="work_end" name="to" placeholder="Ending Date" required>
              <small>
                  <div class="form-check">
                  <input type="checkbox" class="form-check-input" name="current_check" id="currently_working">
                  <label class="form-check-label" for="currently_working">Currently working here</label>
                </div>
              </small>
            </div>
            
          </div>

          <div class="form-group">
            <textarea class="form-control border-yellow" rows="10"  name="description" placeholder="Write description about your job responsibilities"></textarea>
          </div>
          <div class="text-center">
            <button type="submit" class="btn background-yellow">Add</button>
          </div>
          
          
        </form>

          

      </div>
    
    </div>
  </div>
</div>

<!-- Add Academics Modal -->
<div class="modal fade" id="academics" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title">Add Academics</h1>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" >

        <form method="POST" action="<?php echo e(url('add_academics')); ?>">
           <?php echo e(csrf_field()); ?>

          <div class="form-group">
            <label>Institute:</label>
            <input type="text" class="form-control border-yellow" name="institute" placeholder="Name of the institute" required>
          </div>
          <div class="form-group">
            <label>Passing Year:</label>
            <input type="text" class="datepicker form-control border-yellow" name="passing_year" placeholder="Your position there" required>
          </div>
          <div class="form-group row">
            <div class="col-6">
              <label>Exam Type:</label>
              <select class="form-control border-yellow" name="exam_type" required>
                <option value="" disabled selected>-- Select Exam Type --</option>
                <option value="O Level">O Level</option>
                <option value="A Level">A Level</option>
              </select>
            </div>
            <div class="col-6">
              <label>Result:</label>
              <input type="number" class="form-control border-yellow" name="cgpa" placeholder="CGPA/GPA" required>
     
            </div>
          </div>
          

         
          <div class="text-center">
            <button type="submit" class="btn background-yellow">Add</button>
          </div>
          
          
        </form>

          

      </div>
    
    </div>
  </div>
</div>

<!-- Add skills Modal -->
<div class="modal fade" id="skills" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title">Add Skills</h1>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" >

        <form method="POST" action="<?php echo e(url('add_skills')); ?>">
           <?php echo e(csrf_field()); ?>


           <div class="form-group">
            <label>Training Title:</label>
            <input type="text" class="form-control border-yellow" name="training_title" placeholder="Write Trainig Title" required>
          </div>
          <div class="form-group">
            <label>Topic:</label>
            <input type="text" class="form-control border-yellow" name="topic" placeholder="Write Topic" required>
          </div>
          <div class="form-group">
            <label>Institute:</label>
            <input type="text" class="form-control border-yellow" name="institute" placeholder="Write the name of institute" required>
          </div>
          <div class="form-group">
            <label>Country:</label>
            <input type="text" class="form-control border-yellow" name="country" placeholder="Country" required>
          </div>
          <div class="form-group">
            <label>Location:</label>
            <input type="text" class="form-control border-yellow" name="location" placeholder="Located of the office" required>
          </div>
          <div class="form-group row">
            <div class="col-6">
              <label>Year:</label>
              <input type="text" class="datepicker form-control border-yellow" name="year" placeholder="Year" required>
            </div>
            <div class="col-6">
              <label>Duration:</label>
              <input type="text" class="form-control border-yellow" name="duration" placeholder="Duration" required>
            </div>
          </div>
          
     
          <div class="text-center">
            <button type="submit" class="btn background-yellow">Add</button>
          </div>
          
          
        </form>

          

      </div>
    
    </div>
  </div>
</div>


 <?php $__env->startPush('js'); ?>

    <script type="text/javascript">
      $('#pro_pic_choose').on('click', function () {
          $("#profile_picture").click();
      });
      $("#profile_picture").change(function () {
        $("#pro_pic_upload_form").submit();
      });

      $('#currently_working').change(function() {
        if(this.checked) {
            $('#work_end').attr("disabled", "disabled");
            $('#work_end').removeAttr("required");
        }else{
          $('#work_end').removeAttr("disabled");
          $('#work_end').attr("required", "required");
        }     
    });
    </script>

<?php $__env->stopPush(); ?>

  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rrdv69v1l0mv/AlokitoTeacher/resources/views/teachers.blade.php ENDPATH**/ ?>