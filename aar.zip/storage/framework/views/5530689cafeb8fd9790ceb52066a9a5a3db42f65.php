<table class="table table-bordered">
    <thead>
      <tr>
        <th class="font-weight-bold">
        	<span>Sort By:</span>
        	<a class="ml-5" href="#">Recent</a>
        	<a class="ml-5" href="#">Popular</a>
        	<!-- <a href="#" class="text-dark ml-5">Salary</a>  -->
        </th>
        
      </tr>
    </thead>
    	<tbody id="myTable">
    		<?php $__currentLoopData = $job_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v_job_info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
		      	<tr>
		        	<td class="bg-white">
		        		<div class="container-fluid">
		        			<div class="row">
		        				<div class="col-md-2 text-center">
		        					<?php if($v_job_info->image == null): ?>
						          		<i class="fas fa-user-circle fa-5x text-yellow"></i>
							        <?php else: ?>
							        <div class="mx-auto" style="width: 70px; height: 70px;">
							          <img class="img-fluid rounded-circle h-100 w-100" src="<?php echo e(url('images/profile_picture')); ?>/<?php echo e($v_job_info->image); ?>">
							        </div>
							        <?php endif; ?>

							        <h4 class="font-weight-bold mt-3"><a class="text-yellow" href="<?php echo e(url('s')); ?>/<?php echo e($v_job_info->username); ?>"> <?php echo e($v_job_info->name); ?></a></h4>
				        		</div>


			        			<div class="col-md-7">
			        				<span class="font-weight-bold">Job Positon: <?php echo e($v_job_info->job_title); ?></span><br>
			        				
			        				<span class="font-weight-bold">Salary Range:</span><span> <?php echo e($v_job_info->expected_salary_range); ?></span><br>

					        		<span class="font-weight-bold">Type:</span><span><?php if($v_job_info->nature == 1): ?> Permanent <?php elseif($v_job_info->nature == 2): ?> Part-Time  <?php elseif($v_job_info->nature == 3): ?> Contractual <?php else: ?> - <?php endif; ?></span><br> 

					        		<span class="font-weight-bold">Vacancy:</span><span> <?php echo e($v_job_info->vacancy); ?></span><br>
					        		
					        		<span class="font-weight-bold" >Description:</span> 
					        		
					        		<?php echo e(str_limit(strip_tags($v_job_info->description), 150)); ?>

						            
						              <a href="<?php echo e(url('job_detail')); ?>/<?php echo e($v_job_info->job_id); ?>" class="text-yellow">Read More</a>
						            
						            
			        			</div>

			        			<div class="col-md-3">
			        				<small>
			        				Published: <?php echo e(date("jS F, Y", strtotime($v_job_info->created_at))); ?></small>
			        				<br>
			        				<small class="text-danger">
			        				Deadline: <?php echo e(date("jS F, Y", strtotime($v_job_info->deadline))); ?></small>
			        				<br>
			        				
			        				<button type="button" value="<?php echo e($v_job_info->job_id); ?>" class="btn btn-success applyButton" data-toggle="modal" data-target="#coverLetterModal">Apply</button>
			        				<button type="button" value="<?php echo e($v_job_info->job_id); ?>" class="btn border-yellow saveButton">Save</button>
			        			</div>
		        			</div>
		        		</div> 
		        	 </td>
		      	</tr>
	    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
	    </tbody>
</table>

<div id="ajaxPagination" style="padding: 10px;">
   <?php echo e($job_info->links()); ?>

</div><?php /**PATH F:\xampp\htdocs\AlokitoTeacher\resources\views/all-jobs-search.blade.php ENDPATH**/ ?>