<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ResourceRating extends Model
{
    //
    protected $guarded = [];
}
