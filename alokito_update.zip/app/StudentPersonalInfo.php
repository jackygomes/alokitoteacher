<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StudentPersonalInfo extends Model
{
    protected $guarded = [];
    //
}
