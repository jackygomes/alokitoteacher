<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CoursePreview extends Model
{
    protected $guarded = [];
    //
}
