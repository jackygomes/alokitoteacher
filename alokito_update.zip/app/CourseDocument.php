<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CourseDocument extends Model
{
    //
}
