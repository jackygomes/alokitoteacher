<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ResourceVideo extends Model
{
    //
    protected $guarded = [];
}
