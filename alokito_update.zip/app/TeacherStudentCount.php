<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TeacherStudentCount extends Model
{
    protected $guarded = [];
    //
}
