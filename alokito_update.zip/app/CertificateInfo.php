<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CertificateInfo extends Model
{
    //
    protected $guarded = [];
}
