<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class JobPrice extends Model
{
    protected $guarded = [];
    //
}
