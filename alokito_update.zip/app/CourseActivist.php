<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CourseActivist extends Model
{
    protected $guarded = [];
    //
}
