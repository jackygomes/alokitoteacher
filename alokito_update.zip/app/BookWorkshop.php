<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BookWorkshop extends Model
{
    //
}
