<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CourseQuizOption extends Model
{
    protected $guarded = [];
}
